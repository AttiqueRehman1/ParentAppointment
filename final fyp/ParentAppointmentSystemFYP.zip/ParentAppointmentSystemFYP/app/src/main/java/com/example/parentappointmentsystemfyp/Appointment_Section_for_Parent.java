package com.example.parentappointmentsystemfyp;

import static android.content.ContentValues.TAG;
import static java.lang.Double.valueOf;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.databinding.ActivityAppointmentSectionBinding;
import com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide.AdapterTimeSlot;
import com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide.ModelTimeSlot;
import com.example.parentappointmentsystemfyp.rv_for_Notification_bell_parentSide.AdapterNotificationBell;
import com.example.parentappointmentsystemfyp.rv_for_notificationRefferSide.AdapterNotificationReferSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Appointment_Section_for_Parent extends AppCompatActivity {
    ActivityAppointmentSectionBinding binding;
    ArrayList<ModelTimeSlot> tlist;
    String selectedRegNo;
    Button btnOk, btnCancel;
    CalendarView calendarView;
    public static String newdate;
    ArrayList<String> stdList = new ArrayList<>();

    ArrayList<String> stdIssueList = new ArrayList<>();
    public String std_regNo, std_issue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentSectionBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        Intent i = getIntent();
        //cnic = i.getStringExtra("cnic");
        String currentDate = new SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(new Date());
        newdate = currentDate;

        //below data fetching from reject button recylerview of notification bell prnt side
        selectedRegNo = i.getStringExtra("regNO");
        String reason = i.getStringExtra("reason");

        GridLayoutManager manager = new GridLayoutManager(this, 2);
        binding.recyclerViewTimeSlot.setLayoutManager(manager);

        binding.btnCalanderParntsideForAppointmnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog ad = new AlertDialog.Builder(view.getContext()).create();
                View vv = LayoutInflater.from(getApplicationContext()).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
                ad.setView(vv);
                ad.show();
                ad.setCancelable(false);
                calendarView = ad.findViewById(R.id.calander);
                calendarView.setMinDate(System.currentTimeMillis() - 1000);
                calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

                    @Override
                    public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                        Double mont = valueOf(month) + 1;
                        int month1 = mont.intValue();
                        newdate = dayOfMonth + "/" + month1 + "/" + year;
                        Toast.makeText(getApplicationContext(), newdate, Toast.LENGTH_SHORT).show();

                    }
                });
                btnCancel = ad.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ad.dismiss();
                    }
                });
                btnOk = ad.findViewById(R.id.btnOk);
                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        populateRecyclerViewForTimeSlot();
                        ad.dismiss();


                    }
                });


            }
        });

        if (AdapterNotificationBell.flagRejectButton) {
            stdList.add(selectedRegNo);
            ArrayAdapter<String> adp1 = new ArrayAdapter<String>(Appointment_Section_for_Parent.this, android.R.layout.simple_expandable_list_item_1, stdList);
            binding.spinnerStd.setAdapter(adp1);
            stdIssueList.add(reason);
            ArrayAdapter<String> adp2 = new ArrayAdapter<String>(Appointment_Section_for_Parent.this, android.R.layout.simple_expandable_list_item_1, stdIssueList);
            binding.spinnerStdIssue.setAdapter(adp2);
        } else {
            populateStdList();
            populateStdIssueList();
        }
        populateRecyclerViewForTimeSlot();

     /*   binding.buttonRequestAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //binding.buttonRequestAppointment.setBackground(Drawable.createFromPath("gradient_color_for_background_screen"));
                std_regNo = binding.spinnerStd.getSelectedItem().toString();
                std_issue = binding.spinnerStdIssue.getSelectedItem().toString();
                std_time = AdapterTimeSlot.time_get_from_btn;
                std_timeSlot_id = AdapterTimeSlot.id_get_from_btn;
                std_admin_id = AdapterTimeSlot.admin_id_get_from_btn + "";


                JSONObject obj = new JSONObject();
                try {
                    obj.put("tsid", AdapterTimeSlot.timeSLot_id);
                    obj.put("regNo", std_regNo);
                    obj.put("reason", std_issue);
                    obj.put("status", "Pending");
                    obj.put("adminId", std_admin_id);
                    obj.put("parentId", MainActivity.cnic);
                    obj.put("referedTo", "NA");

                    RequestQueue requestQueue = Volley.newRequestQueue(Appointment_Section_for_Parent.this);
                    JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST,
                            MainActivity.url + "/Parent/CreateMeeting",
                            obj, new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Toast.makeText(Appointment_Section_for_Parent.this, "Data Inserted", Toast.LENGTH_LONG).show();
                            Log.d("hhhhh", obj.toString() + "qwwewe");
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(Appointment_Section_for_Parent.this, error.toString(), Toast.LENGTH_LONG).show();
                            Log.d("response", obj.toString() + "qwwewe");

                        }
                    }
                    );
                    requestQueue.add(objectRequest);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });*/

        binding.buttonRequestAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                post();
                finish();
            }
        });
    }

    void postMethodForCreatingMeeting() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                MainActivity.url + "/Parent/CreateMeeting",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Appointment_Section_for_Parent.this, "Data Inserted...", Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Appointment_Section_for_Parent.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("tsid", "523");
                hashMap.put("regNo", "2020-ARID-4247");
                hashMap.put("reason", "std_issue");
                hashMap.put("status", "Pending");
                hashMap.put("adminId", "3240277921986");
                hashMap.put("parentId", "3240277931065");
                hashMap.put("referedTo", "NA");

                return hashMap;
            }
        };

        requestQueue.add(stringRequest);

    }

    // post method for parent appointment,  sending things to database
    void post() {
        std_regNo = binding.spinnerStd.getSelectedItem().toString();
        std_issue = binding.spinnerStdIssue.getSelectedItem().toString();


        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.POST,
                MainActivity.url + "/Parent/CreateMeeting",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Appointment_Section_for_Parent.this, "Appointment Created Successfully...", Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Appointment_Section_for_Parent.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("tsid", AdapterTimeSlot.tsid + "");
                hashMap.put("regNo", std_regNo);
                hashMap.put("reason", std_issue);
                hashMap.put("status", "Pending");
                hashMap.put("date", newdate);
                hashMap.put("adminId", AdapterTimeSlot.adminId);
                hashMap.put("parentId", MainActivity.cnic);
                hashMap.put("referedTo", "NA");
                hashMap.put("studentMeeting", 0 + "");
                Log.d("TAG", hashMap + "");
                return hashMap;
            }
        };

        requestQueue.add(stringRequest);
    }

    void populateStdList() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Parent/GetStudent?pid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject obj = response.getJSONObject(i);
                                String regNo = obj.getString("regNo");

                                stdList.add(regNo);
                                ArrayAdapter<String> adp1 = new ArrayAdapter<String>(Appointment_Section_for_Parent.this, android.R.layout.simple_expandable_list_item_1, stdList);
                                binding.spinnerStd.setAdapter(adp1);


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Appointment_Section_for_Parent.this, "Failed...",
                        Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(jsonObjectRequest);
    }

    void populateRecyclerViewForTimeSlot() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Parent/GetTimeSlot?date=" + newdate,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        tlist = ModelTimeSlot.getTimeSlot(response);
                        AdapterTimeSlot adp = new AdapterTimeSlot(getApplicationContext(), tlist);
                        binding.recyclerViewTimeSlot.setAdapter(adp);
                        adp.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Appointment_Section_for_Parent.this, "time slot failed....",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }

    void populateStdIssueList() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest jsonObjectRequest = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Parent/GetIssueListObject",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject obj = response.getJSONObject(i);
                                String issues = obj.getString("issue");
                                stdIssueList.add(issues);
                                ArrayAdapter<String> adp1 = new ArrayAdapter<String>(Appointment_Section_for_Parent.this, android.R.layout.simple_expandable_list_item_1, stdIssueList);
                                binding.spinnerStdIssue.setAdapter(adp1);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Appointment_Section_for_Parent.this, "Failed...",
                        Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(jsonObjectRequest);
    }
}
