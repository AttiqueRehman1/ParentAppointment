package com.example.parentappointmentsystemfyp.rv_for_timeSlot_RefreSideDataModified;

import static android.content.ContentValues.TAG;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelTimeSlotReferDataModified {
    public String starttime, endtime, day;
    public int ts, timeSlot_id, admin_id_from_timeslot;

    public static ArrayList<ModelTimeSlotReferDataModified> getTimeSlot(JSONArray array) {
        ArrayList<ModelTimeSlotReferDataModified> tlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelTimeSlotReferDataModified tmodel = new ModelTimeSlotReferDataModified();

                tmodel.day = obj.getString("day");
                tmodel.starttime = obj.getString("startTime");
                tmodel.endtime = obj.getString("endTime");
                tmodel.timeSlot_id = obj.getInt("tsid");
                tmodel.admin_id_from_timeslot = obj.getInt("adminId");
                tlist.add(tmodel);
                Log.d("TAG", "getTimeSlot: " + tlist);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
        return tlist;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public int getTs() {
        return ts;
    }

    public void setTs(int ts) {
        this.ts = ts;
    }

    public void setTimeSlot_id(int timeSlot_id) {
        this.timeSlot_id = timeSlot_id;
    }

    public void setAdmin_id_from_timeslot(int admin_id_from_timeslot) {
        this.admin_id_from_timeslot = admin_id_from_timeslot;
    }

    public String getStartTime() {
        return starttime;
    }

    public int getTimeSlot_id() {
        return timeSlot_id;
    }

    public String getEndTime() {
        return endtime;
    }

    public int getAdmin_id_from_timeslot() {
        return admin_id_from_timeslot;
    }
}
