package com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide;

import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;
import com.example.parentappointmentsystemfyp.databinding.ActivityParentDashboardBinding;

public class ViewHolderTimeSlot extends RecyclerView.ViewHolder {
    TextView tv1;
    Button btn;

    public ViewHolderTimeSlot(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.dtv1);
        btn = v.findViewById(R.id.btn1);


    }
}




