package com.example.parentappointmentsystemfyp.rv_for_updateAppointment_Admin;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderUpdateAppointmentAdmin extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5, tv6;
    Button wait1, held1, reschedule1;

    public ViewHolderUpdateAppointmentAdmin(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvHB01);
        tv2 = v.findViewById(R.id.tvHB02);
        tv3 = v.findViewById(R.id.tvHB03);
        tv4 = v.findViewById(R.id.tvHB04);
        tv5 = v.findViewById(R.id.tvHB05);
        held1 = v.findViewById(R.id.btn1Held1);
        wait1 = v.findViewById(R.id.btn1Wait1);
        reschedule1 = v.findViewById(R.id.btn1Reschedule1);


    }
}
