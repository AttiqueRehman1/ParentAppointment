package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.SHORT_ATTENDANCE;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelShortAttendance {
    private  String regno,subject;
    private long percentage;
    public  static ArrayList<ModelShortAttendance> getAllStudentShortAttendance(JSONArray array)
    {
        ArrayList<ModelShortAttendance> slist=new ArrayList<>();
        for(int i=0;i<array.length();i++){

            try {
                JSONObject obj=array.getJSONObject(i);
                ModelShortAttendance smodel=new ModelShortAttendance();
                smodel.regno=obj.getString("regNo");
                smodel.subject=obj.getString("subject");
                smodel.percentage=obj.getLong("percentage");

                slist.add(smodel);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return  slist;
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        subject = subject;
    }

    public long getPercentage() {
        return percentage;
    }

    public void setPercentage(long percentage) {
        this.percentage = percentage;
    }
}
