package com.example.parentappointmentsystemfyp.rv_getHistory_adminside;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelGetHistoryAdminSide {

    String regNo,
            date,
            startTime,
            endTime,
            status, reason, adminId, parentId, referedTo, suggestion, adminFeedback;
    int hid;

    public static ArrayList<ModelGetHistoryAdminSide> getAllStudents(JSONArray array) {
        ArrayList<ModelGetHistoryAdminSide> notificationlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelGetHistoryAdminSide model = new ModelGetHistoryAdminSide();
                model.regNo = obj.getString("regNo");
                model.date = obj.getString("date");
                model.reason = obj.getString("reason");
                model.status = obj.getString("status");
                model.startTime = obj.getString("startTime");
                model.endTime = obj.getString("endTime");
                model.adminFeedback = obj.getString("adminFeedback");
                model.adminId = obj.getString("adminId");
                model.parentId = obj.getString("parentId");
                model.referedTo = obj.getString("referedTo");
                model.suggestion = obj.getString("suggestion");


                notificationlist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return notificationlist;

    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getReferedTo() {
        return referedTo;
    }

    public void setReferedTo(String referedTo) {
        this.referedTo = referedTo;
    }

    public String getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(String suggestion) {
        this.suggestion = suggestion;
    }

    public String getAdminFeedback() {
        return adminFeedback;
    }

    public void setAdminFeedback(String adminFeedback) {
        this.adminFeedback = adminFeedback;
    }

    public int getHid() {
        return hid;
    }

    public void setHid(int hid) {
        this.hid = hid;
    }
}
