package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.databinding.ActivityAdminDashboardBinding;
import com.google.android.material.snackbar.Snackbar;

import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class admin_dashboard extends AppCompatActivity {
    ActivityAdminDashboardBinding binding;
    public static boolean flagNotificationAdmin, flagNotificationReferSide,
            flagWaitingListAdminside, flagMyschedule, flagUpdateAppointmentsAdmin, flagGetHistory = false;
    TextView bellcount;
    ImageView img, img2;
    RecyclerView rvv;
    int mStatusCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAdminDashboardBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        Snackbar.make(view, "WelCome To Admin DashBoard", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
        img2 = findViewById(R.id.Reloading);
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = getIntent();
                // intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                finish();
                startActivity(intent);
            }
        });
        img = findViewById(R.id.notification_icon);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagNotificationAdmin = true;
                flagGetHistory = false;
                flagNotificationReferSide = false;
                flagWaitingListAdminside = false;
                flagUpdateAppointmentsAdmin = false;
                flagMyschedule = false;
                Intent i = new Intent(admin_dashboard.this, NotificationAdmin.class);
                startActivity(i);
                Toast.makeText(admin_dashboard.this, "Admin notification", Toast.LENGTH_SHORT).show();
            }
        });
        bellcount = findViewById(R.id.bell_text_counter);
        notificationCounterForAdmin();
        binding.btnSetAppointmntAdminside.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Appointment_Section_for_Admin.class);
                startActivity(i);
            }
        });
        binding.btnUpdateAppointmentsFroADmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagNotificationReferSide = false;
                flagNotificationAdmin = false;
                flagGetHistory = false;
                flagWaitingListAdminside = false;
                flagMyschedule = false;
                flagUpdateAppointmentsAdmin = true;
                Intent i = new Intent(admin_dashboard.this, NotificationAdmin.class);
                startActivity(i);
            }
        });
        binding.btnDisciplinary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagWaitingListAdminside = true;
                flagNotificationAdmin = false;
                flagNotificationReferSide = false;
                flagMyschedule = false;
                flagUpdateAppointmentsAdmin = false;
                Intent i = new Intent(admin_dashboard.this, NotificationAdmin.class);

                startActivity(i);
            }
        });
        binding.btnHistoryByAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagWaitingListAdminside = false;
                flagNotificationAdmin = false;
                flagMyschedule = false;
                flagGetHistory = true;
                flagUpdateAppointmentsAdmin = false;
                flagNotificationReferSide = false;
                Intent i = new Intent(admin_dashboard.this, NotificationAdmin.class);
                startActivity(i);
            }
        });
        binding.btnMySchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagMyschedule = true;
                flagNotificationAdmin = false;
                flagWaitingListAdminside = false;
                flagUpdateAppointmentsAdmin = false;
                flagNotificationReferSide = false;
                flagGetHistory = false;
                Intent i = new Intent(admin_dashboard.this, SheduleHardCoded.class);

                startActivity(i);
            }
        });
        //binding.tvWelcomeAdmin.setText("");
        binding.btnRescheduleByAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog alertDialog = new AlertDialog.Builder(admin_dashboard.this).create();
                alertDialog.setTitle("Alert");
                alertDialog.setMessage("ReSchedule all today's Appointments");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "re-Schedule",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                reScheduleTodayAppointment();
                                dialog.dismiss();
                            }
                        });
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.setCancelable(false);

                alertDialog.show();

                // reScheduleTodayAppointment();


            }
        });
    }


    private void notificationCounterForAdmin() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/admin/CountNotification?id=" + MainActivity.cnic,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        bellcount.setText(response + "");
                        Toast.makeText(getApplicationContext(), "Good", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });

        requestQueue.add(jsonObjectRequest);
    }
    /*private void notificationCounterForAdmin() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/admin/CountNotificaion?id="+MainActivity.cnic,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        bellcount.setText(response + "");
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        ) {
            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                mStatusCode = response.statusCode;
                return super.parseNetworkResponse(response);

            }
        };
        switch (mStatusCode){
            case HttpURLConnection.HTTP_OK:
                Toast.makeText(this, "200 st", Toast.LENGTH_SHORT).show();
                break;
            case HttpURLConnection.HTTP_NOT_FOUND:
                Toast.makeText(this, "404 st", Toast.LENGTH_SHORT).show();
                break;
            case HttpURLConnection.HTTP_INTERNAL_ERROR:
                Toast.makeText(this, "500 st", Toast.LENGTH_SHORT).show();
                break;
        }
        Toast.makeText(this, mStatusCode + "", Toast.LENGTH_SHORT).show();
        requestQueue.add(jsonObjectRequest);
    }*/

    void reScheduleTodayAppointment() {
        String currentDate = new SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(new Date());
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/ReAdjustMeeting?adminid=3240277921986&date=31/1/2023",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getApplicationContext(), "g", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(jsonObjectRequest);

    }


/*    public void getNotificationForAdmin() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetNotification?admin=2147483647",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        slist = ModelNotificationAdminBell.getAllNotificationAdminBell(response);
                        AdapterNotifiactionAdminBell adp = new AdapterNotifiactionAdminBell(getApplicationContext(),
                                slist);

                        rvv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                        Toast.makeText(getApplicationContext(), "working....",
                                Toast.LENGTH_LONG).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(obj);
    }*/
}