package com.example.parentappointmentsystemfyp;

import static java.lang.Double.valueOf;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;

import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.CGPA.AdapterCgpa;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.CGPA.ModelCgpa;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.Disciplinary.AdapterDisciplinary;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.Disciplinary.ModelDisciplinary;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.FAILED_SUBJECT.AdapterFailedSubject;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.FAILED_SUBJECT.ModelFailedSubject;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.SHORT_ATTENDANCE.AdapterShortAttendance;
import com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.SHORT_ATTENDANCE.ModelShortAttendance;

import org.json.JSONArray;


import java.util.ArrayList;


public class Data_studnt_cgpa_shrt_failedsubject extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<ModelCgpa> slist;
    ArrayList<ModelShortAttendance> shortlist;
    ArrayList<ModelDisciplinary> disciplinarylist;
    ArrayList<ModelFailedSubject> FailedSubjectlist;
    Button btnSendApp, btnOk, btnCancel;
    CalendarView calendarView;
    String date;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_studnt_cgpa_shrt_failedsubject);
        rv = findViewById(R.id.rv_student_data);


        AlertDialog ad = new AlertDialog.Builder(Data_studnt_cgpa_shrt_failedsubject.this).create();
        View v = LayoutInflater.from(Data_studnt_cgpa_shrt_failedsubject.this).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
        ad.setView(v);
        ad.create();

        calendarView = ad.findViewById(R.id.calander);
        calendarView.setMinDate(System.currentTimeMillis() - 1000);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Double mont = valueOf(month) + 1;
                int month1 = mont.intValue();
                date = dayOfMonth + "/" + month1 + "/" + year;

                Toast.makeText(Data_studnt_cgpa_shrt_failedsubject.this, date, Toast.LENGTH_SHORT).show();

            }
        });

        btnCancel = ad.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad.dismiss();
            }
        });


        btnOk = ad.findViewById(R.id.btnOk);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Appointment_Section_for_Admin.flagcgpa) {
                    setAppointmentToLowCGPA();
                } else if (Appointment_Section_for_Admin.flagFailedSubject) {
                    setAppointmentToFailedSubject();
                } else if (Appointment_Section_for_Admin.flagshortAttndnce) {
                    setAppointmentToShortAttendance();
                } else if (Appointment_Section_for_Admin.flagdisciplinary) {
                    setAppointmentToDisciplinary();
                }

                ad.dismiss();
                finish();

            }
        });
        btnSendApp = findViewById(R.id.btn_request_app_For_all_rv_data);
        btnSendApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad.show();


            }
        });


        if (Appointment_Section_for_Admin.flagcgpa) {

            stdRecyclerViewCGPA();
        } else if (Appointment_Section_for_Admin.flagshortAttndnce) {
            {
                stdRecyclerViewShortAttendance();
            }
        } else if (Appointment_Section_for_Admin.flagdisciplinary) {
            {
                stdRecyclerViewDisciplinary();
            }
        } else if (Appointment_Section_for_Admin.flagFailedSubject) {
            {
                stdRecyclerViewFailedSubject();
            }
        }


    }


    public void setAppointmentToFailedSubject() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET, MainActivity.url + "/Admin/FailedAppointment?date=" + date, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(getApplicationContext(), "Appointment Set Successfully", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed subject F", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequest);

    }

    public void setAppointmentToLowCGPA() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET, MainActivity.url + "/Admin/LowCGPAAppointment?date=" + date, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(getApplicationContext(), "Appointment Set Successfully", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Data_studnt_cgpa_shrt_failedsubject.this, "low CGPA f", Toast.LENGTH_SHORT).show();

            }
        });
        requestQueue.add(jsonObjectRequest);

    }

    public void setAppointmentToShortAttendance() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET, MainActivity.url + "/Admin/ShortAttendanceAppointment?date=" + date, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(getApplicationContext(), "Appointment Set Successfully", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(jsonObjectRequest);

    }

    public void setAppointmentToDisciplinary() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET, MainActivity.url + "/Admin/DisciplenaryAppointment?date=" + date, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(getApplicationContext(), "Appointment Set Successfully", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Data_studnt_cgpa_shrt_failedsubject.this, "discp f", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(jsonObjectRequest);

    }

    public void stdRecyclerViewCGPA() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(Request.Method.GET, MainActivity.url + "/admin/GetLowCGPAStudents", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                slist = ModelCgpa.getAllStudentCgpaList(response);

                AdapterCgpa adp = new AdapterCgpa(getApplicationContext(), slist);
                rv.setAdapter(adp);
                adp.notifyDataSetChanged();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }

    public void stdRecyclerViewDisciplinary() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(Request.Method.GET, MainActivity.url + "/admin/GetDisciplenary", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                disciplinarylist = ModelDisciplinary.getAllStudentDisciplinaryList(response);

                AdapterDisciplinary adp = new AdapterDisciplinary(getApplicationContext(), disciplinarylist);
                rv.setAdapter(adp);
                adp.notifyDataSetChanged();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }

    public void stdRecyclerViewFailedSubject() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(Request.Method.GET, MainActivity.url + "/admin/GetFailedSubjects", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                FailedSubjectlist = ModelFailedSubject.getAllStudentFailedSubjectList(response);
                AdapterFailedSubject adp = new AdapterFailedSubject(getApplicationContext(), FailedSubjectlist);
                rv.setAdapter(adp);
                adp.notifyDataSetChanged();


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }

    public void stdRecyclerViewShortAttendance() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(Request.Method.GET, MainActivity.url + "/admin/Getshortattendance", null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                shortlist = ModelShortAttendance.getAllStudentShortAttendance(response);

                AdapterShortAttendance adp = new AdapterShortAttendance(getApplicationContext(), shortlist);
                rv.setAdapter(adp);
                adp.notifyDataSetChanged();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }
}