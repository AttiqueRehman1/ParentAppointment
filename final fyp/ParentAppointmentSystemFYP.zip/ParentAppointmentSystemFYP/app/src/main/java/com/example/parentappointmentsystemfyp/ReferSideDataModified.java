package com.example.parentappointmentsystemfyp;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide.AdapterTimeSlot;
import com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide.ModelTimeSlot;
import com.example.parentappointmentsystemfyp.rv_for_timeSlot_RefreSideDataModified.AdapterTimeSlotReferDataModified;
import com.example.parentappointmentsystemfyp.rv_for_timeSlot_RefreSideDataModified.ModelTimeSlotReferDataModified;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ReferSideDataModified extends AppCompatActivity {
    RecyclerView rv;
    TextView regNo, reason;
    ArrayList<ModelTimeSlotReferDataModified> tlist;
    public static String newdate;
    public static String roleIntent, regnoIntent, midIntent, reasonIntent;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refer_side_data_modified);
        String currentDate = new SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(new Date());
        newdate = currentDate;

        regnoIntent = getIntent().getStringExtra("regNo");
        reasonIntent = getIntent().getStringExtra("reason");
        midIntent = getIntent().getStringExtra("mid");
        roleIntent = getIntent().getStringExtra("role");

        rv = findViewById(R.id.rvTImeSLotReferSide);
        regNo = findViewById(R.id.tvRegNoRefer);
        reason = findViewById(R.id.tvReasonRefer);
        GridLayoutManager manager = new GridLayoutManager(this, 2);
        rv.setLayoutManager(manager);
        populateRecyclerViewForTimeSlot();
        Log.d("TAG", "" + tlist);
        regNo.setText("  " + regnoIntent);
        reason.setText("  " + reasonIntent);

    }

    void populateRecyclerViewForTimeSlot() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetTimeSlotRole?role=" + roleIntent,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        tlist = ModelTimeSlotReferDataModified.getTimeSlot(response);
                        AdapterTimeSlotReferDataModified adp = new AdapterTimeSlotReferDataModified(getApplicationContext(), tlist);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                        Toast.makeText(ReferSideDataModified.this, "Refer Successfully.", Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ReferSideDataModified.this, "No Time Slot AvailAble for Today",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }
}