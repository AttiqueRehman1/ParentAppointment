package com.example.parentappointmentsystemfyp.rv_task_appointmnt_with_studntss;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelNotificationAppWithStudnt {

    String regNo, class1, section;
    double cgpa1;
    int semester;

    public static ArrayList<ModelNotificationAppWithStudnt> getAllNotificationAdminBell(JSONArray array) {
        ArrayList<ModelNotificationAppWithStudnt> notificationlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelNotificationAppWithStudnt model = new ModelNotificationAppWithStudnt();
                model.regNo = obj.getString("regNo");
                model.class1 = obj.getString("class");
                model.semester = obj.getInt("semester");
                model.section = obj.getString("section");
                model.cgpa1 = obj.getDouble("cgpa1");
                notificationlist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return notificationlist;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getClass1() {
        return class1;
    }

    public void setClass1(String class1) {
        this.class1 = class1;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public double getCgpa1() {
        return cgpa1;
    }

    public void setCgpa1(float cgpa1) {
        this.cgpa1 = cgpa1;
    }
}
