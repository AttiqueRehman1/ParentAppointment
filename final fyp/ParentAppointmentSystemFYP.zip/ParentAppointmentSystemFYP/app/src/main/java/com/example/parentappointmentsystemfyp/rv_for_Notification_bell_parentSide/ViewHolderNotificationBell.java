package com.example.parentappointmentsystemfyp.rv_for_Notification_bell_parentSide;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderNotificationBell extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7;
    Button btnAccept, btnReject;

    public ViewHolderNotificationBell(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvNotfication01);
        tv2 = v.findViewById(R.id.tvNotfication02);
        tv3 = v.findViewById(R.id.tvNotfication03);
        tv4 = v.findViewById(R.id.tvNotfication04);
        tv5 = v.findViewById(R.id.tvNotfication05);
        tv6 = v.findViewById(R.id.tvNotfication06);
        tv7 = v.findViewById(R.id.tvrequestForWaitingRescheduleBlaBla);

        btnAccept = v.findViewById(R.id.btnaccept);
        btnReject = v.findViewById(R.id.btnreject);
    }
}
