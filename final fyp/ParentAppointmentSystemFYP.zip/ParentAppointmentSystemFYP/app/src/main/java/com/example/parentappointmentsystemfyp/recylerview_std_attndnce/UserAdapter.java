package com.example.parentappointmentsystemfyp.recylerview_std_attndnce;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;
public class UserAdapter extends RecyclerView.Adapter<UserViewHolder> {
    ArrayList<StudentModel> list ;
    Context context;
    public UserAdapter(Context context,
                       ArrayList<StudentModel> list){
        this.list = list;
        this.context = context;

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_row_cell,parent, false );
        UserViewHolder objHolder = new UserViewHolder(v);
        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        StudentModel cObj = list.get(position);

        holder.tv3.setText(cObj.getSubject());
        holder.tv1.setText(cObj.getClasss());
        holder.tv2.setText(cObj.getPercentage()+"%");
        holder.tv4.setText(cObj.getSection());

      //  holder.itemView.setVisibility(View.GONE);






    }


}



