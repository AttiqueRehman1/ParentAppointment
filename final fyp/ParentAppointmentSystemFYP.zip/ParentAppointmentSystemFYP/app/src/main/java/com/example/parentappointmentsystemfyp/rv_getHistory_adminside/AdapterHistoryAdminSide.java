package com.example.parentappointmentsystemfyp.rv_getHistory_adminside;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;


public class AdapterHistoryAdminSide extends RecyclerView.Adapter<ViewHolderGetHistoryAdminside> {
    ArrayList<ModelGetHistoryAdminSide> list;
    Context context;
    private int lastposition = -1;

    public AdapterHistoryAdminSide(Context context,
                                   ArrayList<ModelGetHistoryAdminSide> list) {
        this.list = list;
        this.context = context;


    }


    @NonNull
    @Override
    public ViewHolderGetHistoryAdminside onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_gethistory_adminside, parent, false);
        ViewHolderGetHistoryAdminside objHolder = new ViewHolderGetHistoryAdminside(vv);
        return objHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderGetHistoryAdminside holder, int position) {
        animation(holder.itemView, position);
        ModelGetHistoryAdminSide cObj = list.get(position);

        holder.tv1.setText("Reg No : " + cObj.getRegNo());
        holder.tv2.setText("Reason : " + cObj.getReason());
        holder.tv3.setText("Date : " + cObj.getDate());
        holder.tv4.setText("Start Time : " + cObj.getStartTime());
        holder.tv5.setText("End Time : " + cObj.getEndTime());
        holder.tv6.setText("Status : " + cObj.status + " ");
        holder.tv7.setText("AdminFeedBack : " + cObj.getAdminFeedback());
        holder.tv8.setText("Suggestions : " + cObj.getSuggestion());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }
    }
}
