package com.example.parentappointmentsystemfyp.rv_for_WaitingList_prntSide;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderWaitingList extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4;
    Button btnOkay;

    public ViewHolderWaitingList(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvHB01);
        tv2 = v.findViewById(R.id.tvHB02);
        tv3 = v.findViewById(R.id.tvHB03);
        tv4 = v.findViewById(R.id.tvHB04);
        btnOkay = v.findViewById(R.id.btncallparentOkay);

    }
}
