package com.example.parentappointmentsystemfyp.rv_for_HistoryButton_prntSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelHistoryButton {

    String regNo, reason, projectIssue, status, startTime, endTime, date, suggestion, adminId;
    int hid, attentive, polite, rudness;
    String adminFeedback;


    public String getAdminFeedback() {
        return adminFeedback;
    }

    public static ArrayList<ModelHistoryButton> getAllStudents(JSONArray array) {
        ArrayList<ModelHistoryButton> notificationlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelHistoryButton model = new ModelHistoryButton();
                model.hid = obj.getInt("hid");
                model.regNo = obj.getString("regNo");
                model.reason = obj.getString("reason");
                model.status = obj.getString("status");
                model.startTime = obj.getString("startTime");
                model.endTime = obj.getString("endTime");
                model.date = obj.getString("date");
                model.adminFeedback = obj.getString("adminFeedback");
                model.suggestion = obj.getString("suggestion");
                model.attentive = obj.getInt("attentive");
                model.polite = obj.getInt("polite");
                model.rudness = obj.getInt("rudness");


                notificationlist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return notificationlist;
    }

    public String getAdminId() {
        return adminId;
    }

    public int getAttentive() {
        return attentive;
    }

    public int getPolite() {
        return polite;
    }

    public int getRudness() {
        return rudness;
    }

    public int getHid() {
        return hid;
    }

    public String getSuggestion() {
        return suggestion;
    }

    public void setHid(int hid) {
        this.hid = hid;
    }

    public void setAdminFeedback(String adminFeedback) {
        this.adminFeedback = adminFeedback;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getProjectIssue() {
        return projectIssue;
    }

    public void setProjectIssue(String projectIssue) {
        this.projectIssue = projectIssue;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
