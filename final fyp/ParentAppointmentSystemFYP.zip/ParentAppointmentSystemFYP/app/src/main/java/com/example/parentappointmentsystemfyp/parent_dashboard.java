package com.example.parentappointmentsystemfyp;

import static com.example.parentappointmentsystemfyp.R.id.AlertRatingbarPolite;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.databinding.ActivityParentDashboardBinding;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class parent_dashboard extends AppCompatActivity {
    static boolean flagHistory, flagWaitingList = false;
    static boolean flagnotificationOnImage = false;
    static boolean flagSnackBar = false;
    static String checkBoxInfo = "";
    static String aa, bb, cc, dd, ff, ee;
    ImageView imgApp, imgWait, imgHis;


    ActivityParentDashboardBinding binding;
    ImageView imageViewBell, imageViewReload;

    TextView bell;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActivityParentDashboardBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        binding.btnratinglisttest.setVisibility(View.GONE);


        // getting cnic of user which is currently login , src MainActivity
        Intent intent = getIntent();
        Bundle b = intent.getExtras();


        bell = findViewById(R.id.bell_text_counter);
        // Getting number of notification depend of pending meeting
        notificationCounter();
        binding.tvWelcomeParent.setText("WELCOME ");

        binding.btnratinglisttest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog ad = new AlertDialog.Builder(parent_dashboard.this).create();
                View v = LayoutInflater.from(parent_dashboard.this).inflate(R.layout.alertdialog_feedback_parent, null);
                ad.setView(v);
                ad.create();
                ad.show();

                @SuppressLint({"MissingInflatedId", "LocalSuppress"})
                RatingBar ratingBar = v.findViewById(AlertRatingbarPolite);
                ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                        Float ratingVal = (Float) rating;
                        int i = ratingVal.intValue();


                        Toast.makeText(getApplicationContext(), i + "", Toast.LENGTH_SHORT).show();
                    }
                });


                Button btnOk = v.findViewById(R.id.btnOk);


            }

        });
        binding.imgWait.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagWaitingList = true;
                flagHistory = false;
                flagnotificationOnImage = false;
                Intent i = new Intent(parent_dashboard.this, History_Section.class);
                startActivity(i);

            }
        });
        binding.btnWaitingList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagWaitingList = true;
                flagHistory = false;
                flagnotificationOnImage = false;
                Intent i = new Intent(parent_dashboard.this, History_Section.class);
                startActivity(i);
            }
        });
        binding.imgHis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagWaitingList = false;
                flagHistory = true;
                flagnotificationOnImage = false;
                Intent i = new Intent(parent_dashboard.this, History_Section.class);
                startActivity(i);

            }
        });
        binding.btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagWaitingList = false;
                flagHistory = true;
                flagnotificationOnImage = false;
                Intent i = new Intent(parent_dashboard.this, History_Section.class);
                startActivity(i);
            }
        });
        imageViewBell = findViewById(R.id.notification_icon);
        imageViewBell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagnotificationOnImage = true;
                flagHistory = false;
                flagWaitingList = false;
                Intent i = new Intent(getApplicationContext(), History_Section.class);
                startActivity(i);
            }
        });
        imageViewReload = findViewById(R.id.Reloading);
        imageViewReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = getIntent();
                finish();
                startActivity(i);
            }
        });
        binding.btnAppointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(parent_dashboard.this, Appointment_Section_for_Parent.class);
                startActivity(i);

            }
        });
        binding.imgApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(parent_dashboard.this, Appointment_Section_for_Parent.class);
                startActivity(i);
            }
        });


    }

    private void notificationCounter() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/parent/CountNotification?id=" + MainActivity.cnic,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        bell.setText(response + "");
                        Toast.makeText(parent_dashboard.this, "Good", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        requestQueue.add(jsonObjectRequest);


    }


}