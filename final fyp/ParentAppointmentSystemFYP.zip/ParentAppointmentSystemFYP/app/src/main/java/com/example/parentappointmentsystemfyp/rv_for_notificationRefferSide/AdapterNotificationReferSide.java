package com.example.parentappointmentsystemfyp.rv_for_notificationRefferSide;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;
import com.example.parentappointmentsystemfyp.SignUp;

import java.util.ArrayList;

public class AdapterNotificationReferSide extends RecyclerView.Adapter<ViewHolderReferSide> {
    ArrayList<ModelNotificationReferSide> list;
    Context context;
    private int lastposition = -1;
    ArrayList<String> referToList = new ArrayList<>();

    public AdapterNotificationReferSide(Context context,
                                        ArrayList<ModelNotificationReferSide> list) {
        this.list = list;
        this.context = context;

    }


    @NonNull
    @Override
    public ViewHolderReferSide onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_notification_referside, parent, false);
        ViewHolderReferSide objHolder = new ViewHolderReferSide(vv);
        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderReferSide holder, int position) {
        animation(holder.itemView, position);
        ModelNotificationReferSide cObj = list.get(position);
        Context context = holder.itemView.getContext();

        holder.tv1.setText("ByAdmin Refer : " + cObj.getRegNo());
        holder.tv2.setText("ByAdmin refer : " + cObj.getReason());
        holder.tv3.setText("ByAdmin Date refer: " + cObj.getDate());
        holder.tv4.setText("Start Time : " + cObj.getStartTime());
        holder.tv5.setText("End Time : " + cObj.getEndTime());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}
