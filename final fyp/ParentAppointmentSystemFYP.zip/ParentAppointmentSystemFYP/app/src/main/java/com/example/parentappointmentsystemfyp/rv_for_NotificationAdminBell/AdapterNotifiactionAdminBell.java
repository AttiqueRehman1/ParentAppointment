package com.example.parentappointmentsystemfyp.rv_for_NotificationAdminBell;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.AddScheduleForAdmin;
import com.example.parentappointmentsystemfyp.Appointment_Section_for_Admin;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;
import com.example.parentappointmentsystemfyp.ReferSideDataModified;
import com.example.parentappointmentsystemfyp.SignUp;

import java.util.ArrayList;

public class AdapterNotifiactionAdminBell extends RecyclerView.Adapter<ViewHolderAdminNotificationBell> {
    ArrayList<ModelNotificationAdminBell> list;
    Context context;
    private int lastposition = -1;
    ArrayList<String> referToList = new ArrayList<>();

    public AdapterNotifiactionAdminBell(Context context,
                                        ArrayList<ModelNotificationAdminBell> list) {
        this.list = list;
        this.context = context;
        referToList.add("DataCell");
        referToList.add("Deputy Director");
        referToList.add("Director");
        referToList.add("Project Committee");
        referToList.add("Accountant");

        referToList.add(0, "Select to refer ");

    }


    @NonNull
    @Override
    public ViewHolderAdminNotificationBell onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_notification_admin_bell, parent, false);
        ViewHolderAdminNotificationBell objHolder = new ViewHolderAdminNotificationBell(vv);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderAdminNotificationBell holder, int position) {
        animation(holder.itemView, position);
        ModelNotificationAdminBell cObj = list.get(position);
        Context context = holder.itemView.getContext();

        holder.tv1.setText("Reg No : " + cObj.getRegNo());
        holder.tv2.setText("Reason : " + cObj.getReason());
        holder.tv3.setText("Date : " + cObj.getDate());
        holder.tv4.setText("Start Time : " + cObj.getStartTime());
        holder.tv5.setText("End Time : " + cObj.getEndTime());

        ArrayAdapter<String> adp1 = new ArrayAdapter<String>(context, android.R.layout.simple_expandable_list_item_1, referToList);
        adp1.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        holder.spnrReferTo.setAdapter(adp1);
        holder.spnrReferTo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String a = holder.spnrReferTo.getSelectedItem().toString();

                if (a.equals("DataCell")) {
                    Intent ia = new Intent(context, ReferSideDataModified.class);
                    ia.putExtra("regNo", cObj.getRegNo());
                    ia.putExtra("reason", cObj.getReason());
                    ia.putExtra("mid", cObj.getMid() + "");
                    ia.putExtra("role", "DataCell");
                    context.startActivity(ia);
                } else if (a.equals("Project Committee")) {
                    Intent ia = new Intent(context, ReferSideDataModified.class);
                    ia.putExtra("regNo", cObj.getRegNo());
                    ia.putExtra("reason", cObj.getReason());
                    ia.putExtra("mid", cObj.getMid() + "");
                    ia.putExtra("role", "Project Committee");
                    context.startActivity(ia);
                } else if (a.equals("Director")) {
                    Intent ia = new Intent(context, ReferSideDataModified.class);
                    ia.putExtra("regNo", cObj.getRegNo());
                    ia.putExtra("reason", cObj.getReason());
                    ia.putExtra("mid", cObj.getMid() + "");
                    ia.putExtra("role", "Director");
                    context.startActivity(ia);
                } else if (a.equals("Deputy Director")) {
                    Intent ia = new Intent(context, ReferSideDataModified.class);
                    ia.putExtra("regNo", cObj.getRegNo());
                    ia.putExtra("reason", cObj.getReason());
                    ia.putExtra("mid", cObj.getMid() + "");
                    ia.putExtra("role", "Deputy Director");
                    context.startActivity(ia);
                } else if (a.equals("Accountant")) {
                    Intent ia = new Intent(context, ReferSideDataModified.class);
                    ia.putExtra("regNo", cObj.getRegNo());
                    ia.putExtra("reason", cObj.getReason());
                    ia.putExtra("mid", cObj.getMid() + "");
                    ia.putExtra("role", "Accountant");
                    context.startActivity(ia);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}
