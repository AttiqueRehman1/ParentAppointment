package com.example.parentappointmentsystemfyp;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SheduleHardCoded extends AppCompatActivity {
    CheckBox m1, m2, m3, m4, m5, m6, m7, m8, m9, m10, m11, m12, m13, m14, m15, m16, m17, m18, m19, m20,
            m21, m22, m23, m24, m25, m26, m27, m28, m29, m30, m31, m32, m33, m34, m35, m36, m37, m38, m39, m40,
            m41, m42, m43, m44, m45, m46, m47, m48, m49, m50, m51, m52, m53, m54, m55, m56, m57, m58, m59, m60,
            m61, m62, m63, m64, m65, m66, m67, m68, m69, m70, m71, m72, m73, m74, m75, m76, m77, m78, m79, m80,
            m81, m82, m83, m84, m85, m86, m87, m88, m89, m90, m91, m92, m93, m94, m95, m96, m97, m98, m99, m100,
            m101, m102, m103, m104, m105, m106, m107, m108, m109, m110, m111, m112, m113, m114, m115, m116, m117, m118, m119, m120,
            m121, m122, m123, m124, m125, m126, m127, m128, m129, m130, m131, m132, m133, m134, m135, m136, m137, m138, m139, m140,
            m141, m142, m143, m144, m145, m146, m147, m148, m149, m150;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shedule_hard_coded);
        init();
        populateMyScheduleTimeSlot();

       /* for (int i = 0; i < 150; i++) {
            // System.out.println("m" + i + "=findViewById(R.id.m" + i + ");");
            Log.d("TAG", "m" + i + ",");
        }*/


    }

    public void init() {
        m1 = findViewById(R.id.m1);
        m2 = findViewById(R.id.m2);
        m3 = findViewById(R.id.m3);
        m4 = findViewById(R.id.m4);
        m5 = findViewById(R.id.m5);
        m6 = findViewById(R.id.m6);
        m7 = findViewById(R.id.m7);
        m8 = findViewById(R.id.m8);
        m9 = findViewById(R.id.m9);
        m10 = findViewById(R.id.m10);
        m11 = findViewById(R.id.m11);
        m12 = findViewById(R.id.m12);
        m13 = findViewById(R.id.m13);
        m14 = findViewById(R.id.m14);
        m15 = findViewById(R.id.m15);
        m16 = findViewById(R.id.m16);
        m17 = findViewById(R.id.m17);
        m18 = findViewById(R.id.m18);
        m19 = findViewById(R.id.m19);
        m20 = findViewById(R.id.m20);
        m21 = findViewById(R.id.m21);
        m22 = findViewById(R.id.m22);
        m23 = findViewById(R.id.m23);
        m24 = findViewById(R.id.m24);
        m25 = findViewById(R.id.m25);
        m26 = findViewById(R.id.m26);
        m27 = findViewById(R.id.m27);
        m28 = findViewById(R.id.m28);
        m29 = findViewById(R.id.m29);
        m30 = findViewById(R.id.m30);
        m31 = findViewById(R.id.m31);
        m32 = findViewById(R.id.m32);
        m33 = findViewById(R.id.m33);
        m34 = findViewById(R.id.m34);
        m35 = findViewById(R.id.m35);
        m36 = findViewById(R.id.m36);
        m37 = findViewById(R.id.m37);
        m38 = findViewById(R.id.m38);
        m39 = findViewById(R.id.m39);
        m40 = findViewById(R.id.m40);
        m41 = findViewById(R.id.m41);
        m42 = findViewById(R.id.m42);
        m43 = findViewById(R.id.m43);
        m44 = findViewById(R.id.m44);
        m45 = findViewById(R.id.m45);
        m46 = findViewById(R.id.m46);
        m47 = findViewById(R.id.m47);
        m48 = findViewById(R.id.m48);
        m49 = findViewById(R.id.m49);
        m50 = findViewById(R.id.m50);
        m51 = findViewById(R.id.m51);
        m52 = findViewById(R.id.m52);
        m53 = findViewById(R.id.m53);
        m54 = findViewById(R.id.m54);
        m55 = findViewById(R.id.m55);
        m56 = findViewById(R.id.m56);
        m57 = findViewById(R.id.m57);
        m58 = findViewById(R.id.m58);
        m59 = findViewById(R.id.m59);
        m60 = findViewById(R.id.m60);
        m61 = findViewById(R.id.m61);
        m62 = findViewById(R.id.m62);
        m63 = findViewById(R.id.m63);
        m64 = findViewById(R.id.m64);
        m65 = findViewById(R.id.m65);
        m66 = findViewById(R.id.m66);
        m67 = findViewById(R.id.m67);
        m68 = findViewById(R.id.m68);
        m69 = findViewById(R.id.m69);
        m70 = findViewById(R.id.m70);
        m71 = findViewById(R.id.m71);
        m72 = findViewById(R.id.m72);
        m73 = findViewById(R.id.m73);
        m74 = findViewById(R.id.m74);
        m75 = findViewById(R.id.m75);
        m76 = findViewById(R.id.m76);
        m77 = findViewById(R.id.m77);
        m78 = findViewById(R.id.m78);
        m79 = findViewById(R.id.m79);
        m80 = findViewById(R.id.m80);
        m81 = findViewById(R.id.m81);
        m82 = findViewById(R.id.m82);
        m83 = findViewById(R.id.m83);
        m84 = findViewById(R.id.m84);
        m85 = findViewById(R.id.m85);
        m86 = findViewById(R.id.m86);
        m87 = findViewById(R.id.m87);
        m88 = findViewById(R.id.m88);
        m89 = findViewById(R.id.m89);
        m90 = findViewById(R.id.m90);
        m91 = findViewById(R.id.m91);
        m92 = findViewById(R.id.m92);
        m93 = findViewById(R.id.m93);
        m94 = findViewById(R.id.m94);
        m95 = findViewById(R.id.m95);
        m96 = findViewById(R.id.m96);
        m97 = findViewById(R.id.m97);
        m98 = findViewById(R.id.m98);
        m99 = findViewById(R.id.m99);
        m100 = findViewById(R.id.m100);
        m101 = findViewById(R.id.m101);
        m102 = findViewById(R.id.m102);
        m103 = findViewById(R.id.m103);
        m104 = findViewById(R.id.m104);
        m105 = findViewById(R.id.m105);
        m106 = findViewById(R.id.m106);
        m107 = findViewById(R.id.m107);
        m108 = findViewById(R.id.m108);
        m109 = findViewById(R.id.m109);
        m110 = findViewById(R.id.m110);
        m111 = findViewById(R.id.m111);
        m112 = findViewById(R.id.m112);
        m113 = findViewById(R.id.m113);
        m114 = findViewById(R.id.m114);
        m115 = findViewById(R.id.m115);
        m116 = findViewById(R.id.m116);
        m117 = findViewById(R.id.m117);
        m118 = findViewById(R.id.m118);
        m119 = findViewById(R.id.m119);
        m120 = findViewById(R.id.m120);
        m121 = findViewById(R.id.m121);
        m122 = findViewById(R.id.m122);
        m123 = findViewById(R.id.m123);
        m124 = findViewById(R.id.m124);
        m125 = findViewById(R.id.m125);
        m126 = findViewById(R.id.m126);
        m127 = findViewById(R.id.m127);
        m128 = findViewById(R.id.m128);
        m129 = findViewById(R.id.m129);
        m130 = findViewById(R.id.m130);
        m131 = findViewById(R.id.m131);
        m132 = findViewById(R.id.m132);
        m133 = findViewById(R.id.m133);
        m134 = findViewById(R.id.m134);
        m135 = findViewById(R.id.m135);
        m136 = findViewById(R.id.m136);
        m137 = findViewById(R.id.m137);
        m138 = findViewById(R.id.m138);
        m139 = findViewById(R.id.m139);
        m140 = findViewById(R.id.m140);
        m141 = findViewById(R.id.m141);
        m142 = findViewById(R.id.m142);
        m143 = findViewById(R.id.m143);
        m144 = findViewById(R.id.m144);
        m145 = findViewById(R.id.m145);
        m146 = findViewById(R.id.m146);
        m147 = findViewById(R.id.m147);
        m148 = findViewById(R.id.m148);
        m149 = findViewById(R.id.m149);
        m150 = findViewById(R.id.m150);
    }

    public void populateMyScheduleTimeSlot() {
        ArrayList<String> checkBoxesIds = new ArrayList<>();
        checkBoxesIds.add(0, "");

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetTimeSlot?adminid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                JSONObject obj = response.getJSONObject(i);
                                boolean availabilit = obj.getBoolean("availability");
                                int tsis = obj.getInt("tsid");
                                String tsisS = tsis + "";

                                if (i == 0) {
                                    m1.setChecked(availabilit);
                                    m1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 1) {
                                    m2.setChecked(availabilit);
                                    m2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 2) {
                                    m3.setChecked(availabilit);
                                    m3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 3) {
                                    m4.setChecked(availabilit);
                                    m4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 4) {
                                    m5.setChecked(availabilit);
                                    m5.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 5) {
                                    m6.setChecked(availabilit);
                                    m6.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 6) {
                                    m7.setChecked(availabilit);
                                    m7.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 7) {
                                    m8.setChecked(availabilit);
                                    m8.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 8) {
                                    m9.setChecked(availabilit);
                                    m9.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 9) {
                                    m10.setChecked(availabilit);
                                    m10.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 10) {
                                    m11.setChecked(availabilit);
                                    m11.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 11) {
                                    m12.setChecked(availabilit);
                                    m12.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 12) {
                                    m13.setChecked(availabilit);
                                    m13.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 13) {
                                    m14.setChecked(availabilit);
                                    m14.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 14) {
                                    m15.setChecked(availabilit);
                                    m15.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 15) {
                                    m16.setChecked(availabilit);
                                    m16.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 16) {
                                    m17.setChecked(availabilit);
                                    m17.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 17) {
                                    m18.setChecked(availabilit);
                                    m18.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 18) {
                                    m19.setChecked(availabilit);
                                    m19.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 19) {
                                    m20.setChecked(availabilit);
                                    m20.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 20) {
                                    m21.setChecked(availabilit);
                                    m21.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 21) {
                                    m22.setChecked(availabilit);
                                    m22.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 22) {
                                    m23.setChecked(availabilit);
                                    m23.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 23) {
                                    m24.setChecked(availabilit);
                                    m24.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 24) {
                                    m25.setChecked(availabilit);
                                    m25.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 25) {
                                    m26.setChecked(availabilit);
                                    m26.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 26) {
                                    m27.setChecked(availabilit);
                                    m27.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 27) {
                                    m28.setChecked(availabilit);
                                    m28.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 28) {
                                    m29.setChecked(availabilit);
                                    m29.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 29) {
                                    m30.setChecked(availabilit);
                                    m30.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 30) {
                                    m31.setChecked(availabilit);
                                    m31.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 31) {
                                    m32.setChecked(availabilit);
                                    m32.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 32) {
                                    m33.setChecked(availabilit);
                                    m33.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 33) {
                                    m34.setChecked(availabilit);
                                    m34.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 34) {
                                    m35.setChecked(availabilit);
                                    m35.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 35) {
                                    m36.setChecked(availabilit);
                                    m36.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 36) {
                                    m37.setChecked(availabilit);
                                    m37.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 37) {
                                    m38.setChecked(availabilit);
                                    m38.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 38) {
                                    m39.setChecked(availabilit);
                                    m39.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 39) {
                                    m40.setChecked(availabilit);
                                    m40.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 40) {
                                    m41.setChecked(availabilit);
                                    m41.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 41) {
                                    m42.setChecked(availabilit);
                                    m42.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 42) {
                                    m43.setChecked(availabilit);
                                    m43.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 43) {
                                    m44.setChecked(availabilit);
                                    m44.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 44) {
                                    m45.setChecked(availabilit);
                                    m45.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 45) {
                                    m46.setChecked(availabilit);
                                    m46.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 46) {
                                    m47.setChecked(availabilit);
                                    m47.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 47) {
                                    m48.setChecked(availabilit);
                                    m48.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 48) {
                                    m49.setChecked(availabilit);
                                    m49.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 49) {
                                    m50.setChecked(availabilit);
                                    m50.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 50) {
                                    m51.setChecked(availabilit);
                                    m51.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 51) {
                                    m52.setChecked(availabilit);
                                    m52.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 52) {
                                    m53.setChecked(availabilit);
                                    m53.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 53) {
                                    m54.setChecked(availabilit);
                                    m54.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 54) {
                                    m55.setChecked(availabilit);
                                    m55.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 55) {
                                    m56.setChecked(availabilit);
                                    m56.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 56) {
                                    m57.setChecked(availabilit);
                                    m57.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 57) {
                                    m58.setChecked(availabilit);
                                    m58.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 58) {
                                    m59.setChecked(availabilit);
                                    m59.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 59) {
                                    m60.setChecked(availabilit);
                                    m60.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 60) {
                                    m61.setChecked(availabilit);
                                    m61.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 61) {
                                    m62.setChecked(availabilit);
                                    m62.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 62) {
                                    m63.setChecked(availabilit);
                                    m63.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 63) {
                                    m64.setChecked(availabilit);
                                    m64.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 64) {
                                    m65.setChecked(availabilit);
                                    m65.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 65) {
                                    m66.setChecked(availabilit);
                                    m66.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 66) {
                                    m67.setChecked(availabilit);
                                    m67.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 67) {
                                    m68.setChecked(availabilit);
                                    m68.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 68) {
                                    m69.setChecked(availabilit);
                                    m69.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 69) {
                                    m70.setChecked(availabilit);
                                    m70.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 70) {
                                    m71.setChecked(availabilit);
                                    m71.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 71) {
                                    m72.setChecked(availabilit);
                                    m72.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 72) {
                                    m73.setChecked(availabilit);
                                    m73.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 73) {
                                    m74.setChecked(availabilit);
                                    m74.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 74) {
                                    m75.setChecked(availabilit);
                                    m75.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 75) {
                                    m76.setChecked(availabilit);
                                    m76.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 76) {
                                    m77.setChecked(availabilit);
                                    m77.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 77) {
                                    m78.setChecked(availabilit);
                                    m78.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 78) {
                                    m79.setChecked(availabilit);
                                    m79.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 79) {
                                    m80.setChecked(availabilit);
                                    m80.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 80) {
                                    m81.setChecked(availabilit);
                                    m81.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 81) {
                                    m82.setChecked(availabilit);
                                    m82.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 82) {
                                    m83.setChecked(availabilit);
                                    m83.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 83) {
                                    m84.setChecked(availabilit);
                                    m84.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 84) {
                                    m85.setChecked(availabilit);
                                    m85.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 85) {
                                    m86.setChecked(availabilit);
                                    m86.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 86) {
                                    m87.setChecked(availabilit);
                                    m87.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 87) {
                                    m88.setChecked(availabilit);
                                    m88.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 88) {
                                    m89.setChecked(availabilit);
                                    m89.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 89) {
                                    m90.setChecked(availabilit);
                                    m90.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 90) {
                                    m91.setChecked(availabilit);
                                    m91.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 91) {
                                    m92.setChecked(availabilit);
                                    m92.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 92) {
                                    m93.setChecked(availabilit);
                                    m93.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 93) {
                                    m94.setChecked(availabilit);
                                    m94.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 94) {
                                    m95.setChecked(availabilit);
                                    m95.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 95) {
                                    m96.setChecked(availabilit);
                                    m96.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 96) {
                                    m97.setChecked(availabilit);
                                    m97.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 97) {
                                    m98.setChecked(availabilit);
                                    m98.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 98) {
                                    m99.setChecked(availabilit);
                                    m99.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 99) {
                                    m100.setChecked(availabilit);
                                    m100.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 100) {
                                    m101.setChecked(availabilit);
                                    m101.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 101) {
                                    m102.setChecked(availabilit);
                                    m102.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 102) {
                                    m103.setChecked(availabilit);
                                    m103.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 103) {
                                    m104.setChecked(availabilit);
                                    m104.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 104) {
                                    m105.setChecked(availabilit);
                                    m105.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 105) {
                                    m106.setChecked(availabilit);
                                    m106.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 106) {
                                    m107.setChecked(availabilit);
                                    m107.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 107) {
                                    m108.setChecked(availabilit);
                                    m108.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 108) {
                                    m109.setChecked(availabilit);
                                    m109.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 109) {
                                    m110.setChecked(availabilit);
                                    m110.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 110) {
                                    m111.setChecked(availabilit);
                                    m111.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 111) {
                                    m112.setChecked(availabilit);
                                    m112.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 112) {
                                    m113.setChecked(availabilit);
                                    m113.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 113) {
                                    m114.setChecked(availabilit);
                                    m114.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 114) {
                                    m115.setChecked(availabilit);
                                    m115.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 115) {
                                    m116.setChecked(availabilit);
                                    m116.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 116) {
                                    m117.setChecked(availabilit);
                                    m117.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 117) {
                                    m118.setChecked(availabilit);
                                    m118.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 118) {
                                    m119.setChecked(availabilit);
                                    m119.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 119) {
                                    m120.setChecked(availabilit);
                                    m120.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 120) {
                                    m121.setChecked(availabilit);
                                    m121.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 121) {
                                    m122.setChecked(availabilit);
                                    m122.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 122) {
                                    m123.setChecked(availabilit);
                                    m123.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 123) {
                                    m124.setChecked(availabilit);
                                    m124.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 124) {
                                    m125.setChecked(availabilit);
                                    m125.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 125) {
                                    m126.setChecked(availabilit);
                                    m126.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 126) {
                                    m127.setChecked(availabilit);
                                    m127.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 127) {
                                    m128.setChecked(availabilit);
                                    m128.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 128) {
                                    m129.setChecked(availabilit);
                                    m129.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 129) {
                                    m130.setChecked(availabilit);
                                    m130.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 130) {
                                    m131.setChecked(availabilit);
                                    m131.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 131) {
                                    m132.setChecked(availabilit);
                                    m132.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 132) {
                                    m133.setChecked(availabilit);
                                    m133.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 133) {
                                    m134.setChecked(availabilit);
                                    m134.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 134) {
                                    m135.setChecked(availabilit);
                                    m135.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 135) {
                                    m136.setChecked(availabilit);
                                    m136.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 136) {
                                    m137.setChecked(availabilit);
                                    m137.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 137) {
                                    m138.setChecked(availabilit);
                                    m138.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 138) {
                                    m139.setChecked(availabilit);
                                    m139.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 139) {
                                    m140.setChecked(availabilit);
                                    m140.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 140) {
                                    m141.setChecked(availabilit);
                                    m141.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 141) {
                                    m142.setChecked(availabilit);
                                    m142.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 142) {
                                    m143.setChecked(availabilit);
                                    m143.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 143) {
                                    m144.setChecked(availabilit);
                                    m144.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 144) {
                                    m145.setChecked(availabilit);
                                    m145.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 145) {
                                    m146.setChecked(availabilit);
                                    m146.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 146) {
                                    m147.setChecked(availabilit);
                                    m147.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 147) {
                                    m148.setChecked(availabilit);
                                    m148.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 148) {
                                    m149.setChecked(availabilit);
                                    m149.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }
                                if (i == 149) {
                                    m150.setChecked(availabilit);
                                    m150.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                        @Override
                                        public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                                            UpdateAvailability(tsis, b);
                                        }
                                    });
                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...",
                        Toast.LENGTH_LONG).show();
            }

        }

        );
        requestQueue.add(obj);


    }


    public void UpdateAvailability(int tsid, boolean avb) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/admin/UpdateAvailability?tsid=" + tsid + "&avb=" + avb,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(getApplicationContext(), "Availability Updated . .", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
        requestQueue.add(jsonObjectRequest);

    }
}