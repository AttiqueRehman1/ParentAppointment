package com.example.parentappointmentsystemfyp.recylerview_std_attndnce;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class StudentModel {
    private  String regno,subject,classs,section;
    private int percentage;
    public  static ArrayList<StudentModel> getAllStudents(JSONArray array)
    {
        ArrayList<StudentModel> slist=new ArrayList<>();
        for(int i=0;i<array.length();i++){

            try {
                JSONObject obj=array.getJSONObject(i);
                StudentModel smodel=new StudentModel();
                smodel.regno=obj.getString("regNo");
                smodel.subject=obj.getString("subject");
                smodel.percentage=obj.getInt("percentage");
               // smodel.section=obj.getString("section");

                slist.add(smodel);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return  slist;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public String getClasss() {
        return classs;
    }

    public void setClasss(String classs) {
        this.classs = classs;
    }

    public int getPercentage() {
        return percentage;
    }

    public void setPercentage(int percentage) {
        this.percentage = percentage;
    }
}
