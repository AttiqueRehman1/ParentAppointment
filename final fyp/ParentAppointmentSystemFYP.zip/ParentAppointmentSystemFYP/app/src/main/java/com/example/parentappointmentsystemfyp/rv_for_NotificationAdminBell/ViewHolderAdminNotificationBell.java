package com.example.parentappointmentsystemfyp.rv_for_NotificationAdminBell;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.Appointment_Section_for_Parent;
import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class ViewHolderAdminNotificationBell extends RecyclerView.ViewHolder {
    TextView tv1,tv2,tv3,tv4,tv5;
    Spinner spnrReferTo;


    public ViewHolderAdminNotificationBell(@NonNull View v) {
        super(v);
        tv1= v.findViewById(R.id.tvHB01);
        tv2 = v.findViewById(R.id.tvHB02);
        tv3= v.findViewById(R.id.tvHB03);
        tv4= v.findViewById(R.id.tvHB04);
        tv5= v.findViewById(R.id.tvHB05);
        spnrReferTo=v.findViewById(R.id.spinnerReferTo);

    }
}
