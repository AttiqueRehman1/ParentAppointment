package com.example.parentappointmentsystemfyp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.nio.channels.InterruptedByTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final String[] users = new String[]{"Parent1", "Student1", "Admin1","Ihsan"};
    public static final String url = "http://192.168.93.83/BIIT_Parent_Appointment/api";
    ActivityMainBinding binding;
    public static String cnic = "";
    public static String regno = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        getSupportActionBar().hide();

        ArrayAdapter<String> adp = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_expandable_list_item_1, users);
        binding.etxtsigninusername.setAdapter(adp);

        setTitle("BIIT Parent Appointment System  ");

        binding.tvsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, ReferSideDataModified.class);
                startActivity(in);
            }
        });
        binding.btnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = binding.etxtsigninusername.getText().toString();
                String userPass = binding.etxtsigninpassword.getText().toString();

                if (userName.isEmpty()) {
                    binding.etxtsigninusername.setFocusable(true);
                    binding.etxtsigninusername.setError("Enter Username");
                    return;
                }
                if (userPass.isEmpty()) {
                    binding.etxtsigninpassword.setFocusable(true);
                    binding.etxtsigninpassword.setError("Enter Password");
                    return;
                }
                ProgressDialog progress = new ProgressDialog(MainActivity.this);
                progress.setMessage("Loading..");
                progress.setProgressStyle(1);
                progress.show();

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                        Request.Method.GET,
                        url + "/User/logIn?username=" + userName + "&pass=" + userPass,
                        null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    String name = response.getString("userName");
                                    String password = response.getString("password");
                                    String role = response.getString("role");
                                    regno = response.getString("regNo");
                                    cnic = response.getString("cnic");

                                    Bundle b = new Bundle();
                                    b.putString("cnic", cnic);
                                    b.putString("aridNo", regno);

                                    if (name.equals(userName) && password.equals(userPass)) {
                                        if (role.equals("Student")) {
                                            Intent i = new Intent(MainActivity.this, student_dashboard.class);
                                            i.putExtras(b);
                                            startActivity(i);
                                        } else if (role.equals("Admin")) {
                                            Intent i = new Intent(MainActivity.this, admin_dashboard.class);
                                            startActivity(i);
                                        } else if (role.equals("Parent")) {
                                            Intent i = new Intent(MainActivity.this, parent_dashboard.class);
                                            i.putExtras(b);
                                            startActivity(i);
                                        } else if (role.equals("Datacell")) {
                                            Intent i = new Intent(MainActivity.this, ReferSideDashBoard.class);
                                            startActivity(i);
                                        } else if (role.equals("Project")) {
                                            Intent i = new Intent(MainActivity.this, ReferSideDashBoard.class);
                                            i.putExtras(b);
                                            startActivity(i);
                                        } else if (role.equals("DDirector")) {
                                            Intent i = new Intent(MainActivity.this, ReferSideDashBoard.class);
                                            startActivity(i);
                                        }
                                    } else {
                                        Toast.makeText(MainActivity.this, "Not Found..", Toast.LENGTH_LONG).show();
                                    }
                                    progress.dismiss();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "UserName or Password incorrect", Toast.LENGTH_LONG).show();
                    }
                });
                requestQueue.add(jsonObjectRequest);
            }
        });
        binding.tvforgetpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, parent_dashboard.class);
                startActivity(i);
            }
        });
    }
}