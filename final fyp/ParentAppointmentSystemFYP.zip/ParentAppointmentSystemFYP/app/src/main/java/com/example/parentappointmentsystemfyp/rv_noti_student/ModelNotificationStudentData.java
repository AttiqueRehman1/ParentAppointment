package com.example.parentappointmentsystemfyp.rv_noti_student;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelNotificationStudentData {

    String regNo, reason, status, date, startTime, endTime;

    public static ArrayList<ModelNotificationStudentData> getAllNotificationAdminBell(JSONArray array) {
        ArrayList<ModelNotificationStudentData> notificationlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelNotificationStudentData model = new ModelNotificationStudentData();
                model.regNo = obj.getString("regNo");
                model.reason = obj.getString("reason");
                model.status = obj.getString("status");
                model.date = obj.getString("date");
                model.startTime = obj.getString("startTime");
                model.endTime = obj.getString("endTime");
                notificationlist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return notificationlist;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
