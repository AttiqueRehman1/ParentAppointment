package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.parentappointmentsystemfyp.databinding.ActivityMainBinding;
import com.example.parentappointmentsystemfyp.databinding.ActivitySignUpBinding;

public class SignUp extends AppCompatActivity {
    ActivitySignUpBinding binding;


    EditText signup_user_name, signup_user_Gmail,
            signup_user_PHoneNO, signup_user_CNIC,
            signup_user_password, signup_user_reEnterPassword;
    TextView tv_signin;
    Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);


        setContentView(R.layout.activity_sign_up);


        signup_user_name = findViewById(R.id.etxtsignupusername);
        signup_user_CNIC = findViewById(R.id.etxtsignup_cnic);
        signup_user_Gmail = findViewById(R.id.etxtsignup_gmail);
        signup_user_PHoneNO = findViewById(R.id.etxtsignup_phonenumber);
        signup_user_password = findViewById(R.id.etxtsignup_password);
        signup_user_reEnterPassword = findViewById(R.id.etxtsignup_reEnterPassword);

        // es pay click krny sy signup page sy signin page pa move hoga
        binding.tvsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SignUp.this, MainActivity.class);
                startActivity(i);
            }
        });
        btnSignUp = findViewById(R.id.btnsignup);
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = signup_user_name.getText().toString();
                String email = signup_user_Gmail.getText().toString();
                String password = signup_user_password.getText().toString();
                String re_enterPassword = signup_user_reEnterPassword.getText().toString();

                if (name.isEmpty()) {
                    signup_user_name.setError("Please Enter Your name ");
                }
                if (email.isEmpty()) {
                    signup_user_Gmail.setError("Please Enter Email ");
                }
                //Intent i=new Intent(SignUp.this,admin_dashboard.class);
                // startActivity(i);
            }
        });


    }
}