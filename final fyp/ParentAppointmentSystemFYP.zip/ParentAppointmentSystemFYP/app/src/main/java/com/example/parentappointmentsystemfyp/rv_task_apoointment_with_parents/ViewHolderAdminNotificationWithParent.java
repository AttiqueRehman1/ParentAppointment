package com.example.parentappointmentsystemfyp.rv_task_apoointment_with_parents;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderAdminNotificationWithParent extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5;



    public ViewHolderAdminNotificationWithParent(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvTask01);
        tv2 = v.findViewById(R.id.tvTask02);
        tv3 = v.findViewById(R.id.tvTask03);
        tv5 = v.findViewById(R.id.tvTask05);


    }
}
