package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.parentappointmentsystemfyp.databinding.ActivityMainBinding;

public class forget_password extends AppCompatActivity {
    EditText mail;
    Button MailButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
        setTitle("Forget Password");
        mail=findViewById(R.id.editTextTextEmailAddress);
        MailButton=findViewById(R.id.send_mail_button);
        mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

















    }
}