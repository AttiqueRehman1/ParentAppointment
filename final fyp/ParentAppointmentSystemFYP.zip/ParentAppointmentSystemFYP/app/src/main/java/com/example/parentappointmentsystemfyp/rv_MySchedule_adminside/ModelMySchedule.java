package com.example.parentappointmentsystemfyp.rv_MySchedule_adminside;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelMySchedule {

    String day, startTime, endTime,adminId;
    int tsid;
    boolean availability;


    public static ArrayList<ModelMySchedule> getAllWaitingList(JSONArray array) {
        ArrayList<ModelMySchedule> waitinglist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelMySchedule model = new ModelMySchedule();
                model.startTime = obj.getString("startTime");
                model.endTime = obj.getString("endTime");
                model.day = obj.getString("date");
                model.adminId=obj.getString("adminId");
                model.availability=obj.getBoolean("availability");
                model.tsid=obj.getInt("tsid");



                waitinglist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return waitinglist;


    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public int getTsid() {
        return tsid;
    }

    public void setTsid(int tsid) {
        this.tsid = tsid;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }
}
