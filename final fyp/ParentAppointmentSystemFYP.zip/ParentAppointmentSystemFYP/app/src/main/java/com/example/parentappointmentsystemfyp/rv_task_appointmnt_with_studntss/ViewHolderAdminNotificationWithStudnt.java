package com.example.parentappointmentsystemfyp.rv_task_appointmnt_with_studntss;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderAdminNotificationWithStudnt extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5;


    public ViewHolderAdminNotificationWithStudnt(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvTaskStd01);
        tv2 = v.findViewById(R.id.tvTaskStd02);
        tv3 = v.findViewById(R.id.tvTaskStd03);
        tv5 = v.findViewById(R.id.tvTaskStd04);


    }
}
