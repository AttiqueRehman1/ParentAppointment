package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class ReferSideDashBoard extends AppCompatActivity {
    TextView bellcount;
    ImageView img, img2Reloading;
    Button btnReferSideDashboard;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refer_side_dash_board);
        img = findViewById(R.id.notification_icon);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                admin_dashboard.flagNotificationReferSide=true;
                admin_dashboard.flagGetHistory=false;
                admin_dashboard.flagMyschedule=false;
                admin_dashboard.flagNotificationAdmin=false;
                admin_dashboard.flagUpdateAppointmentsAdmin=false;
                admin_dashboard.flagWaitingListAdminside=false;
                startActivity(new Intent(ReferSideDashBoard.this,NotificationAdmin.class));

            }
        });


        btnReferSideDashboard=findViewById(R.id.btnMyScheduleFOrReferSideDashboard);
        btnReferSideDashboard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ReferSideDashBoard.this,SheduleHardCoded.class));
            }
        });

        img2Reloading = findViewById(R.id.Reloading);
        img2Reloading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = getIntent();
                // intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                finish();
                startActivity(intent);
            }
        });
       bellcount = findViewById(R.id.bell_text_counter);
       notificationCounterForAdmin();
    }
    public void notificationCounterForAdmin() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/admin/CountNotification?id=" + MainActivity.cnic,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        bellcount.setText(response + "");
                        Toast.makeText(getApplicationContext(), "Good", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }
}