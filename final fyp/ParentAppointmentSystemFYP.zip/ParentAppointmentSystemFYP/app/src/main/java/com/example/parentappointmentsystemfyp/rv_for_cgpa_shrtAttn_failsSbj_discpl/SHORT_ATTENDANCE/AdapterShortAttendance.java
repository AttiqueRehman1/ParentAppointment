package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.SHORT_ATTENDANCE;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterShortAttendance extends RecyclerView.Adapter<ViewHolderShortAttendance> {
    ArrayList<ModelShortAttendance> list;
    private int lastposition = -1;
    Context context;

    public AdapterShortAttendance(Context context,
                                  ArrayList<ModelShortAttendance> list) {
        this.list = list;
        this.context = context;

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @NonNull
    @Override
    public ViewHolderShortAttendance onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_studntdata_short_attendance, parent, false);
        ViewHolderShortAttendance objHolder = new ViewHolderShortAttendance(v);
        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderShortAttendance holder, int position) {
        animation(holder.itemView, position);
        ModelShortAttendance cObj = list.get(position);

        holder.tv1.setText(cObj.getRegno());
        holder.tv2.setText(cObj.getSubject());
        holder.tv3.setText(cObj.getPercentage() + "%");

    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}



