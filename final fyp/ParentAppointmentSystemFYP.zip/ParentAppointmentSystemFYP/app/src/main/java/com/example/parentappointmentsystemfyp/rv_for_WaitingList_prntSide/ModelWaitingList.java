package com.example.parentappointmentsystemfyp.rv_for_WaitingList_prntSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelWaitingList {

    String regNo, reason, status, date, parentId, adminId;
    int tsId;


    public static ArrayList<ModelWaitingList> getAllWaitingList(JSONArray array) {
        ArrayList<ModelWaitingList> waitinglist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelWaitingList model = new ModelWaitingList();
                model.regNo = obj.getString("regNo");
                model.reason = obj.getString("reason");
                model.date = obj.getString("date");
                model.status = obj.getString("status");
                model.parentId = obj.getString("parentId");
                model.adminId = obj.getString("adminId");
                model.tsId = obj.getInt("tsId");
                waitinglist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return waitinglist;

    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public int getTsId() {
        return tsId;
    }

    public void setTsId(int tsId) {
        this.tsId = tsId;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
