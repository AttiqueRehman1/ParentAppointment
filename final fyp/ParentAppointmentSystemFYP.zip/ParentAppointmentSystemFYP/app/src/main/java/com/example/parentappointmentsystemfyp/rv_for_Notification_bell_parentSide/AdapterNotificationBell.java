package com.example.parentappointmentsystemfyp.rv_for_Notification_bell_parentSide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.Appointment_Section_for_Parent;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class AdapterNotificationBell extends RecyclerView.Adapter<ViewHolderNotificationBell> {
    ArrayList<ModelNotificationBell> list;
    public static boolean flagRejectButton = false;
    Context context;
    private int lastposition = -1;

    public AdapterNotificationBell(Context context,
                                   ArrayList<ModelNotificationBell> list) {
        this.list = list;
        this.context = context;

    }


    @NonNull
    @Override
    public ViewHolderNotificationBell onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_notification_bell_parentside, parent, false);
        ViewHolderNotificationBell objHolder = new ViewHolderNotificationBell(vv);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderNotificationBell holder, @SuppressLint("RecyclerView") int position) {
        animation(holder.itemView, position);
        ModelNotificationBell cObj = list.get(position);
        holder.tv1.setText("Reg No : " + cObj.getRegNo() + "   " + cObj.getMid());
        holder.tv2.setText("Reason : " + cObj.getReason());
        holder.tv3.setText("Date : " + cObj.getDate());
        holder.tv4.setText("Start Time : " + cObj.getStartTime());
        holder.tv5.setText("End Time : " + cObj.getEndTime());
        holder.tv6.setText("Status : " + cObj.getStatus() + "  ");

        if (cObj.getStatus().equals("Pending")) {
            holder.btnAccept.setVisibility(View.GONE);
            holder.btnReject.setVisibility(View.GONE);
            holder.tv7.setVisibility(View.GONE);
        }
        if (cObj.getStatus().equals("Reschedualed") || cObj.getStatus().equals("Request")) {
            holder.btnAccept.setBackgroundResource(R.drawable.btn_color_change_by_clicking);
            holder.btnReject.setBackgroundResource(R.drawable.btn_color_change_by_clicking);
            holder.tv7.setText("Appointment is reschedule by Admin");
        }
        if (cObj.getStatus().equals("Waiting")) {
            holder.btnAccept.setBackgroundResource(R.drawable.btn_color_change_by_clicking);
            holder.btnReject.setBackgroundResource(R.drawable.btn_color_change_by_clicking);
            holder.tv7.setText("Appointment is reschedule by Admin");
        }
        holder.btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest jsonObjectRequest = new StringRequest(
                        Request.Method.GET,
                        MainActivity.url + "/Parent/UpdateMeetingStatus?mid=" + cObj.getMid() + "&status=Pending",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(context, "Meeting Accepted", Toast.LENGTH_SHORT).show();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
                requestQueue.add(jsonObjectRequest);

                RequestQueue req2 = Volley.newRequestQueue(context);
                StringRequest stringRequest = new StringRequest(Request.Method.POST,
                        MainActivity.url + "/Parent/InsertWaitingList",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(context, "Added into waiting list", Toast.LENGTH_LONG).show();
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
                    @Nullable
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> hashMap = new HashMap<>();
                        hashMap.put("tsid", cObj.getTsid() + "");
                        hashMap.put("regNo", "2019-arid-82");
                        hashMap.put("reason", "shrt");
                        hashMap.put("date", cObj.getDate());
                        hashMap.put("adminId", cObj.getAdminId());
                        hashMap.put("parentId", MainActivity.cnic);
                        hashMap.put("status", "Waiting");
                        return hashMap;
                    }
                };

                req2.add(stringRequest);
                list.remove(position);
                notifyDataSetChanged();


            }

        });
        holder.btnReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagRejectButton = true;
                String regNO = cObj.getRegNo();
                String reason = cObj.reason;
                Bundle b = new Bundle();
                b.putString("regNO", regNO);
                b.putString("reason", reason);

                Context context = holder.itemView.getContext();
                Intent i = new Intent(holder.itemView.getContext(), Appointment_Section_for_Parent.class);
                i.putExtras(b);
                context.startActivity(i);


            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}
