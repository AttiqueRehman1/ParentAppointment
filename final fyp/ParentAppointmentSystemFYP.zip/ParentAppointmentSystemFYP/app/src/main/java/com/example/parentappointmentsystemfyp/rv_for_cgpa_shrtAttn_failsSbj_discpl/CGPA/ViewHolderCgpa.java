package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.CGPA;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderCgpa extends RecyclerView.ViewHolder {
    TextView tv1,tv2,tv3,tv4;
    public ViewHolderCgpa(@NonNull View v) {
        super(v);
        tv1= v.findViewById(R.id.dtv1);
        tv2 = v.findViewById(R.id.dtv2);


    }
}




