package com.example.parentappointmentsystemfyp;

import static android.content.ContentValues.TAG;
import static java.lang.Double.valueOf;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide.AdapterTimeSlot;
import com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide.ModelTimeSlot;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class IndividualAppointmentForAdmin extends AppCompatActivity {
    EditText etxtInd;
    CalendarView calendarView;
    Button btnOk, btnCancel;
    public static String newdate;
    Button btnGetDate, btnSetIndApp;
    RecyclerView rv;
    ArrayList<ModelTimeSlot> tlist;
    String dayOfWeekName = "";
    String selectedMonth, TimeFormatDAy_MonthNAme_Year;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_appointment_for_admin);
        etxtInd = findViewById(R.id.etxtIndApp);
        btnGetDate = findViewById(R.id.btnGetDateIndApp);
        rv = findViewById(R.id.rvIndApp);
        btnSetIndApp = findViewById(R.id.btnSetIndApp);

        btnGetDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog ad = new AlertDialog.Builder(view.getContext()).create();
                View vv = LayoutInflater.from(getApplicationContext()).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
                ad.setView(vv);
                ad.show();
                ad.setCancelable(false);
                calendarView = ad.findViewById(R.id.calander);
                calendarView.setMinDate(System.currentTimeMillis() - 1000);
                calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

                    @Override
                    public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                        Double mont = valueOf(month) + 1;
                        int month1 = mont.intValue();
                        newdate = dayOfMonth + "/" + month1 + "/" + year;

                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, month, dayOfMonth);
                        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

                        switch (dayOfWeek) {
                            case Calendar.SUNDAY:
                                dayOfWeekName = "Sunday";
                                break;
                            case Calendar.MONDAY:
                                dayOfWeekName = "Monday";
                                break;
                            case Calendar.TUESDAY:
                                dayOfWeekName = "Tuesday";
                                break;
                            case Calendar.WEDNESDAY:
                                dayOfWeekName = "Wednesday";
                                break;
                            case Calendar.THURSDAY:
                                dayOfWeekName = "Thursday";
                                break;
                            case Calendar.FRIDAY:
                                dayOfWeekName = "Friday";
                                break;
                            case Calendar.SATURDAY:
                                dayOfWeekName = "Saturday";
                                break;
                        }
                        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
                        selectedMonth = months[month];
                        TimeFormatDAy_MonthNAme_Year = dayOfMonth + "/" + selectedMonth + "/" + year;
                        //get current month name from calander
//                        calendar.setTimeInMillis(calendarView.getDate());
//                        String monthName = calendar.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault());
                        Toast.makeText(getApplicationContext(), newdate, Toast.LENGTH_SHORT).show();

                    }
                });
                btnCancel = ad.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ad.dismiss();
                    }
                });
                btnOk = ad.findViewById(R.id.btnOk);
                btnOk.setOnClickListener(new View.OnClickListener() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onClick(View view) {
                        populateRecyclerViewForTimeSlot();
                        btnGetDate.setText(TimeFormatDAy_MonthNAme_Year + "  " + dayOfWeekName);
                        ad.dismiss();


                    }
                });


            }
        });

        btnSetIndApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String a = AdapterTimeSlot.adminId;
                String b = AdapterTimeSlot.tsid + "";
                String regNo = etxtInd.getText().toString();

                Toast.makeText(IndividualAppointmentForAdmin.this, a + " " + b, Toast.LENGTH_SHORT).show();
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                StringRequest jsonObjectRequest = new StringRequest(
                        Request.Method.GET,
                        MainActivity.url + "/admin/CustomMeeting?regno=" + regNo + "&adminid=" + a + "&date=" + newdate + "&time=" + AdapterTimeSlot.time + "&reason=fee",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(getApplicationContext(), "Good", Toast.LENGTH_SHORT).show();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(IndividualAppointmentForAdmin.this, error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
                requestQueue.add(jsonObjectRequest);

            }
        });


    }

    void populateRecyclerViewForTimeSlot() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Parent/GetTimeSlot?date=" + newdate,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        tlist = ModelTimeSlot.getTimeSlot(response);
                        AdapterTimeSlot adp = new AdapterTimeSlot(getApplicationContext(), tlist);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(IndividualAppointmentForAdmin.this, "time slot failed....",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }

}