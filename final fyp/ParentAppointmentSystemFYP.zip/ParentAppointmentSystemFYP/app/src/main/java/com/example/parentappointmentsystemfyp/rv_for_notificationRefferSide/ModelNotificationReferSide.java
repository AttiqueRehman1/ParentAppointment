package com.example.parentappointmentsystemfyp.rv_for_notificationRefferSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelNotificationReferSide {

    String regNo, reason, projectIssue, status, startTime, endTime, date;


    public static ArrayList<ModelNotificationReferSide> getAllNotificationReferSide(JSONArray array) {
        ArrayList<ModelNotificationReferSide> notificationlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelNotificationReferSide model = new ModelNotificationReferSide();
                model.regNo = obj.getString("regNo");
                model.reason = obj.getString("reason");
                model.status = obj.getString("status");
                model.startTime = obj.getString("startTime");
                model.endTime = obj.getString("endTime");
                model.date = obj.getString("date");
                notificationlist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return notificationlist;


    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getProjectIssue() {
        return projectIssue;
    }

    public void setProjectIssue(String projectIssue) {
        this.projectIssue = projectIssue;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
