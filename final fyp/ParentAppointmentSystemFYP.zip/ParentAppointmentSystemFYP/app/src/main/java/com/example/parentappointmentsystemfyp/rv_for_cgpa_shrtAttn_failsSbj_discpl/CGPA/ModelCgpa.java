package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.CGPA;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelCgpa {
    private  String regno;
    private double cgpa;
    public  static ArrayList<ModelCgpa> getAllStudentCgpaList(JSONArray array)
    {
        ArrayList<ModelCgpa> slist=new ArrayList<>();
        for(int i=0;i<array.length();i++){

            try {
                JSONObject obj=array.getJSONObject(i);
                ModelCgpa smodel=new ModelCgpa();
                smodel.regno=obj.getString("regNo");
                smodel.cgpa=obj.getDouble("cgpa1");




                slist.add(smodel);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return  slist;
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public double getCgpa() {
        return cgpa;
    }

    public void setCgpa(Long cgpa) {
        this.cgpa = cgpa;
    }
}
