package com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelTimeSlot {
    String day, startTime, endTime, adminId;
    boolean availability;
    int tsid;

    public static ArrayList<ModelTimeSlot> getTimeSlot(JSONArray array) {
        ArrayList<ModelTimeSlot> tlist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelTimeSlot tmodel = new ModelTimeSlot();
                tmodel.tsid = obj.getInt("tsid");
                tmodel.day = obj.getString("day");
                tmodel.startTime = obj.getString("startTime");
                tmodel.endTime = obj.getString("endTime");
                tmodel.adminId = obj.getString("adminId");

                tlist.add(tmodel);

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
        return tlist;
    }

    public String getDay() {
        return day;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getAdminId() {
        return adminId;
    }

    public boolean isAvailability() {
        return availability;
    }

    public int getTsid() {
        return tsid;
    }
}
