package com.example.parentappointmentsystemfyp.rv_noti_student;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterNotificationStudentData extends RecyclerView.Adapter<ViewHolderNotificationStudentData> {
    ArrayList<ModelNotificationStudentData> list;
    Context context;
    private int lastposition = -1;
    ArrayList<String> referToList = new ArrayList<>();

    public AdapterNotificationStudentData(Context context,
                                          ArrayList<ModelNotificationStudentData> list) {
        this.list = list;
        this.context = context;

    }


    @NonNull
    @Override
    public ViewHolderNotificationStudentData onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_studnt_notofication_data, parent, false);
        ViewHolderNotificationStudentData objHolder = new ViewHolderNotificationStudentData(vv);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderNotificationStudentData holder, int position) {
        animation(holder.itemView, position);
        ModelNotificationStudentData cObj = list.get(position);
        Context context = holder.itemView.getContext();
        holder.tv1.setText("Reg No : " + cObj.getRegNo());
        holder.tv2.setText("reason : " + cObj.getReason());
        holder.tv3.setText("status : " + cObj.getStatus());
        holder.tv4.setText("date : " + cObj.getDate());
        holder.tv5.setText("StartTime : " + cObj.getStartTime() + "EndTime : " + cObj.getEndTime());


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}
