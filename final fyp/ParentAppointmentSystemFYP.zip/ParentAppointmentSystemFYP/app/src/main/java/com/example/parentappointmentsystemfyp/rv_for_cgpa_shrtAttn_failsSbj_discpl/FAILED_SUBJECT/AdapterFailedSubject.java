package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.FAILED_SUBJECT;


import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterFailedSubject extends RecyclerView.Adapter<ViewHolderFailedSubject> {
    ArrayList<ModelFailedSubject> list;
    Context context;
    private int lastposition = -1;

    public AdapterFailedSubject(Context context,
                                ArrayList<ModelFailedSubject> list) {
        this.list = list;
        this.context = context;

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @NonNull
    @Override
    public ViewHolderFailedSubject onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_studntdata_failedsubject, parent, false);
        ViewHolderFailedSubject objHolder = new ViewHolderFailedSubject(v);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderFailedSubject holder, int position) {
        animation(holder.itemView, position);
        ModelFailedSubject cObj = list.get(position);

        holder.tv1.setText(("Reg NO : ") + cObj.getRegno());
        holder.tv2.setText(("Semester : ") + cObj.getSemester());
        holder.tv3.setText(("Subject : ") + cObj.getSubject());
        holder.tv4.setText(("Grade : ") + cObj.getGrade() + "  ");

    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }
}



