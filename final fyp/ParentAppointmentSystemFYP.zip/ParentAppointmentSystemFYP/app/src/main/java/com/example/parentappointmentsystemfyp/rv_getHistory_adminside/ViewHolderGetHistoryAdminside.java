package com.example.parentappointmentsystemfyp.rv_getHistory_adminside;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderGetHistoryAdminside extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5, tv6,tv7,tv8;

    public ViewHolderGetHistoryAdminside(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tv1G_H_admin);
        tv2 = v.findViewById(R.id.tv2G_H_admin);
        tv3 = v.findViewById(R.id.tv3G_H_admin);
        tv4 = v.findViewById(R.id.tv4G_H_admin);
        tv5 = v.findViewById(R.id.tv5G_H_admin);
        tv6 = v.findViewById(R.id.tv6G_H_admin);
        tv7 = v.findViewById(R.id.tv7G_H_admin);
        tv8 = v.findViewById(R.id.tv8G_H_admin);




    }

}
