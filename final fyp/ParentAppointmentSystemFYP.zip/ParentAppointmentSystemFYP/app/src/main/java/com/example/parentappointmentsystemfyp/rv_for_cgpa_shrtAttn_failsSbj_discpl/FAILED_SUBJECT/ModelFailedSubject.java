package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.FAILED_SUBJECT;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelFailedSubject {
    private  String regno,semester,grade,subjectt;

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSubject() {
        return subjectt;
    }

    public void setSubject(String subject) {
        this.subjectt = subject;
    }

    public  static ArrayList<ModelFailedSubject> getAllStudentFailedSubjectList(JSONArray array)
    {
        ArrayList<ModelFailedSubject> slist=new ArrayList<>();
        for(int i=0;i<array.length();i++){

            try {
                JSONObject obj=array.getJSONObject(i);
                ModelFailedSubject smodel=new ModelFailedSubject();
                smodel.regno=obj.getString("regNo");
                smodel.semester=obj.getString("semester");
                smodel.subjectt=obj.getString("subject");
                smodel.grade=obj.getString("grade");
                slist.add(smodel);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return  slist;
    }


}
