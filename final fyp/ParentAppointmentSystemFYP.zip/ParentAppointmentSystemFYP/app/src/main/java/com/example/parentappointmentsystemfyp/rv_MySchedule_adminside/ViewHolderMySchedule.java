package com.example.parentappointmentsystemfyp.rv_MySchedule_adminside;

import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderMySchedule extends RecyclerView.ViewHolder {
    TextView tv1,tv2,tv3;
    Switch switchButton;
    View deleteIcon;
    public ViewHolderMySchedule(@NonNull View v) {
        super(v);
        tv1= v.findViewById(R.id.tv01Schedule);
        tv2 = v.findViewById(R.id.tv02Schedule);
        tv3= v.findViewById(R.id.tv03Schedule);
        switchButton =v.findViewById(R.id.swAvailability);
        deleteIcon=v.findViewById(R.id.viewDeleteICon);




    }
}
