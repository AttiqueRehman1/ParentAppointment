package com.example.parentappointmentsystemfyp.rv_for_notificationRefferSide;

import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderReferSide extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5;


    public ViewHolderReferSide(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvrs01);
        tv2 = v.findViewById(R.id.tvrs02);
        tv3 = v.findViewById(R.id.tvrs03);
        tv4 = v.findViewById(R.id.tvrs04);
        tv5 = v.findViewById(R.id.tvrs05);

    }
}
