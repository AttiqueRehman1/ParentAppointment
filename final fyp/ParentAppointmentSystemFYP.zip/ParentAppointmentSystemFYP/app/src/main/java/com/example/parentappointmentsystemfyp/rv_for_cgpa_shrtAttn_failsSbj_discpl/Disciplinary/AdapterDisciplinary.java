package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.Disciplinary;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterDisciplinary extends RecyclerView.Adapter<ViewHolderDisciplinary> {
    ArrayList<ModelDisciplinary> list;
    Context context;
    private int lastposition = -1;

    public AdapterDisciplinary(Context context,
                               ArrayList<ModelDisciplinary> list) {
        this.list = list;
        this.context = context;

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @NonNull
    @Override
    public ViewHolderDisciplinary onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_studntdata_disciplinary, parent, false);
        ViewHolderDisciplinary objHolder = new ViewHolderDisciplinary(v);
        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDisciplinary holder, int position) {
        animation(holder.itemView, position);
        ModelDisciplinary cObj = list.get(position);

        holder.tv1.setText(cObj.getRegno());
        holder.tv2.setText(cObj.getDisciplinary());

    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}



