package com.example.parentappointmentsystemfyp.rv_for_WaitingList_prntSide;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterWaitingList extends RecyclerView.Adapter<ViewHolderWaitingList> {
    ArrayList<ModelWaitingList> list;
    Context context;
    private int lastposition = -1;

    public AdapterWaitingList(Context context,
                              ArrayList<ModelWaitingList> list) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolderWaitingList onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_waitinglist_parntside, parent, false);
        ViewHolderWaitingList objHolder = new ViewHolderWaitingList(vv);
        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderWaitingList holder, int position) {
        animation(holder.itemView, position);
        ModelWaitingList cObj = list.get(position);
        holder.tv1.setText("Reg No : " + cObj.getRegNo());
        holder.tv2.setText("Reason : " + cObj.getReason());
        holder.tv3.setText("Date : " + cObj.getDate());
        holder.btnOkay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest jsonObjectRequest = new StringRequest(
                        Request.Method.GET,
                        MainActivity.url + "/Parent/AcceptMeeting?id=" + cObj,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(context, "Ok.", Toast.LENGTH_SHORT).show();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                            }
                        });
                requestQueue.add(jsonObjectRequest);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}
