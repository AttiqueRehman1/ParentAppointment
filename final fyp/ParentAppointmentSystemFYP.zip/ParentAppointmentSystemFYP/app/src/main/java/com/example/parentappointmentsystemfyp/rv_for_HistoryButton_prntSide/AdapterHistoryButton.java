package com.example.parentappointmentsystemfyp.rv_for_HistoryButton_prntSide;

import static android.content.ContentValues.TAG;
import static com.example.parentappointmentsystemfyp.R.id.AlertRatingbarAttentive;
import static com.example.parentappointmentsystemfyp.R.id.AlertRatingbarPolite;
import static com.example.parentappointmentsystemfyp.R.id.AlertRatingbarRudeness;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.History_Section;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;
import com.example.parentappointmentsystemfyp.parent_dashboard;
import com.example.parentappointmentsystemfyp.rv_getHistory_adminside.AdapterHistoryAdminSide;
import com.example.parentappointmentsystemfyp.rv_getHistory_adminside.ModelGetHistoryAdminSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class AdapterHistoryButton extends RecyclerView.Adapter<ViewHolderHistoryButton> {
    ArrayList<ModelHistoryButton> list;
    Context context;
    private int lastposition = -1;
    static String checkBoxInfo = "";
    static String aa, bb, cc, dd, ff, ee;
    public int hid, starPolite, starAttentive, starRudeness;

    public AdapterHistoryButton(Context context, ArrayList<ModelHistoryButton> list) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolderHistoryButton onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_history_button_prndside, parent, false);
        ViewHolderHistoryButton objHolder = new ViewHolderHistoryButton(vv);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderHistoryButton holder, @SuppressLint("RecyclerView") int position) {
        animation(holder.itemView, position);
        ModelHistoryButton cObj = list.get(position);

        holder.tv1.setText("Reg No : " + cObj.getRegNo());
        holder.tv2.setText("Reason : " + cObj.getReason());
        holder.tv3.setText("Date : " + cObj.getDate());
        holder.tv4.setText("Start Time : " + cObj.getStartTime());
        holder.tv5.setText("End Time : " + cObj.getEndTime());
        holder.tv6.setText("Status : " + cObj.status);

        if (cObj.getSuggestion().equals("N/A")) {
            holder.btnR.setVisibility(View.VISIBLE);
            holder.ratingBar1.setVisibility(View.GONE);
            holder.ratingBar2.setVisibility(View.GONE);
            holder.ratingBar3.setVisibility(View.GONE);
            holder.att1.setVisibility(View.GONE);
            holder.att2.setVisibility(View.GONE);
            holder.att3.setVisibility(View.GONE);


        } else
            holder.btnR.setVisibility(View.GONE);

        float a = holder.ratingBar1.getRating();

        holder.ratingBar1.setRating(cObj.getAttentive());
        holder.ratingBar2.setRating(cObj.getPolite());
        holder.ratingBar3.setRating(cObj.getRudness());


        holder.btnR.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("MissingInflatedId")
            @Override
            public void onClick(View view) {


                //holder.btnR.setBackgroundResource(R.drawable.reverse_color_for_recylerview);
                //  holder.btnR.setText("FeedBack Submitted...");
                AlertDialog ad = new AlertDialog.Builder(context).create();
                View v = LayoutInflater.from(context).inflate(R.layout.alertdialog_feedback_parent, null);
                ad.setView(v);
                ad.setCancelable(false);
                ad.create();
                ad.show();

                @SuppressLint({"MissingInflatedId", "LocalSuppress"})
                RatingBar ratingBarPolite = v.findViewById(AlertRatingbarPolite);
                RatingBar ratingBarAttentive = v.findViewById(AlertRatingbarAttentive);
                RatingBar ratingBarRudeness = v.findViewById(AlertRatingbarRudeness);
                ratingBarPolite.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        Float ratingVal = (Float) rating;
                        starPolite = ratingVal.intValue();
                    }
                });
                ratingBarAttentive.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        Float ratingVal = (Float) rating;
                        starAttentive = ratingVal.intValue();

                    }
                });
                ratingBarRudeness.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                        Float ratingVal = (Float) rating;
                        starRudeness = ratingVal.intValue();

                    }
                });


                Button btnOk = v.findViewById(R.id.btnOk);
                EditText suggestion = v.findViewById(R.id.feedbackSuggestion);

                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                        StringRequest jsonObjectRequest = new StringRequest(
                                Request.Method.GET,
                                MainActivity.url + "/Parent/Feedback?hid=" + cObj.getHid() + "&attentive=" + starAttentive + "&polite=" + starPolite + "&rudness=" + starRudeness + "&suggestion=" + suggestion.getText().toString(),
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        ad.dismiss();
                                        AlertDialog ad = new AlertDialog.Builder(context).create();
                                        ad.setMessage("Thank you for the Feedback");
                                        ad.setButton(AlertDialog.BUTTON_POSITIVE, "OKAY", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialogInterface, int i) {
                                                list.remove(position);
                                                notifyDataSetChanged();
                                                ad.dismiss();
                                            }
                                        });
                                        ad.show();


                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(context, "f", Toast.LENGTH_SHORT).show();
                                    }
                                });
                        requestQueue.add(jsonObjectRequest);

                    }
                });
                Button btnCancel = v.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ad.dismiss();

                    }
                });

            }
        });


    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

//    public void feedback() {
//        RequestQueue requestQueue = Volley.newRequestQueue(context);
//        StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET,
//                MainActivity.url + "/Parent/Feedback?hid=" + hid + "&rating=" + stars + "&msg=" + checkBoxInfo + "&suggestion=Kuch b",
//                new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//                AlertDialog ad = new AlertDialog.Builder(context).create();
//                ad.setMessage("Thank You For Your Feedback ");
//                ad.setButton(AlertDialog.BUTTON_POSITIVE, "Okay", new DialogInterface.OnClickListener() {
//                    public void onClick(DialogInterface dialog, int which) {
//                        dialog.dismiss();
//                    }
//                });
//                ad.show();
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(context, error.toString() + " feedback", Toast.LENGTH_SHORT).show();
//            }
//        });
//        requestQueue.add(jsonObjectRequest);
//    }

    public void feedbackWithMultipleRating() {
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "Parent/Feedback?hid=6&attentive=4.0&polite=4.0&rudness=1.0&suggestion=good",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(context, "g", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, "f", Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(jsonObjectRequest);

    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }


}
