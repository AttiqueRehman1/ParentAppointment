package com.example.parentappointmentsystemfyp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.rv_MySchedule_adminside.AdapterMySchedule;
import com.example.parentappointmentsystemfyp.rv_MySchedule_adminside.ModelMySchedule;
import com.example.parentappointmentsystemfyp.rv_for_NotificationAdminBell.AdapterNotifiactionAdminBell;
import com.example.parentappointmentsystemfyp.rv_for_NotificationAdminBell.ModelNotificationAdminBell;
import com.example.parentappointmentsystemfyp.rv_for_notificationRefferSide.AdapterNotificationReferSide;
import com.example.parentappointmentsystemfyp.rv_for_notificationRefferSide.ModelNotificationReferSide;
import com.example.parentappointmentsystemfyp.rv_for_updateAppointment_Admin.AdapterUpdateAppointmentAdmin;
import com.example.parentappointmentsystemfyp.rv_for_updateAppointment_Admin.ModelUpdateAppointmentAdmin;
import com.example.parentappointmentsystemfyp.rv_getHistory_adminside.AdapterHistoryAdminSide;
import com.example.parentappointmentsystemfyp.rv_getHistory_adminside.ModelGetHistoryAdminSide;
import com.example.parentappointmentsystemfyp.rv_waitinglist_adminside.AdapterWaitingListAdminSide;
import com.example.parentappointmentsystemfyp.rv_waitinglist_adminside.ModelWaitingListAdminSide;

import org.json.JSONArray;

import java.util.ArrayList;

public class NotificationAdmin extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<ModelNotificationAdminBell> slist;
    ArrayList<ModelNotificationReferSide> referSideList;
    ArrayList<ModelUpdateAppointmentAdmin> ulist;
    ArrayList<ModelWaitingListAdminSide> waitingList;
    ArrayList<ModelMySchedule> myScheduleList;
    ArrayList<ModelGetHistoryAdminSide> getHistoryAdminSides;
    TextView tv_addTimeSlot, tvdetailsupperbar;
    public static boolean flagResponseList = true;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_admin);
        admin_dashboard.flagNotificationReferSide = true;


        rv = findViewById(R.id.recylerviewForAdminNotification);
        tvdetailsupperbar = findViewById(R.id.tv_details_stime_etime_date_Wtc);

        if (admin_dashboard.flagNotificationAdmin) {
            getNotificationForAdmin();
            tvdetailsupperbar.setVisibility(View.GONE);

        } else if (admin_dashboard.flagUpdateAppointmentsAdmin) {
            getUpdateAppointmentsForAdmin();
            tvdetailsupperbar.setVisibility(View.GONE);

        } else if (admin_dashboard.flagWaitingListAdminside) {
            tvdetailsupperbar.setVisibility(View.GONE);

            populateWaitingListAdminSideRecylerView();
        } else if (admin_dashboard.flagGetHistory) {
            populateHistoryAdminSide();
            tvdetailsupperbar.setText("Held Appointments History");
            tvdetailsupperbar.setGravity(1);
            tvdetailsupperbar.setTextSize(20);
        } else if (admin_dashboard.flagNotificationReferSide) {
            getNotificationForReferSide();
            tvdetailsupperbar.setVisibility(View.GONE);

        }
//        if (myScheduleList != null) {
//            android.app.AlertDialog ad = new android.app.AlertDialog.Builder(rv.getContext()).create();
//            ad.setMessage("There is no Schedule Added");
//            ad.setCancelable(false);
//            ad.setButton(AlertDialog.BUTTON_POSITIVE, "Okay", new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int which) {
//                    // startActivity(new Intent(History_Section.this,parent_dashboard.class));
//                    finish();
//                    dialog.dismiss();
//                }
//            });
//            ad.setButton(AlertDialog.BUTTON_NEGATIVE, "Add Timeslot ", new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int which) {
//                    // startActivity(new Intent(History_Section.this,parent_dashboard.class));
//                    startActivity(new Intent(NotificationAdmin.this, AddScheduleForAdmin.class));
//                    dialog.dismiss();
//                }
//            });
//            ad.show();
//        }
    }

    public void getNotificationForAdmin() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetNotification?adminid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        slist = ModelNotificationAdminBell.getAllNotificationAdminBell(response);
                        AdapterNotifiactionAdminBell adp = new AdapterNotifiactionAdminBell(getApplicationContext(),
                                slist);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                AlertDialog alertDialog = new AlertDialog.Builder(NotificationAdmin.this).create();
                alertDialog.setTitle("Alert");
                alertDialog.setMessage("No Appointments data found  ");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                finish();
                            }
                        });
                alertDialog.setCancelable(false);
                alertDialog.show();
            }
        });
        requestQueue.add(obj);
    }

    public void getNotificationForReferSide() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetNotification?adminid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        referSideList = ModelNotificationReferSide.getAllNotificationReferSide(response);
                        AdapterNotificationReferSide adp = new AdapterNotificationReferSide(getApplicationContext(),
                                referSideList);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(obj);
    }

    public void getUpdateAppointmentsForAdmin() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetNotification?adminid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        ulist = ModelUpdateAppointmentAdmin.getAllNotificationAdminBell(response);
                        AdapterUpdateAppointmentAdmin adp = new AdapterUpdateAppointmentAdmin(getApplicationContext(),
                                ulist);

                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...", Toast.LENGTH_LONG).show();
            }
        });
        requestQueue.add(obj);
    }

    public void populateWaitingListAdminSideRecylerView() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetWaitingList",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        waitingList = ModelWaitingListAdminSide.getAllWaitingList(response);
                        AdapterWaitingListAdminSide adp = new AdapterWaitingListAdminSide(getApplicationContext(),
                                waitingList);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);


    }

    public void populateMyScheduleTimeSlot() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetTimeSlot?adminid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        myScheduleList = ModelMySchedule.getAllWaitingList(response);
                        AdapterMySchedule adp = new AdapterMySchedule(getApplicationContext(),
                                myScheduleList);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...",
                        Toast.LENGTH_LONG).show();
                flagResponseList = false;

            }
        });
        requestQueue.add(obj);


    }

    public void populateHistoryAdminSide() {

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/GetHistory?adminid=" + MainActivity.cnic,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        getHistoryAdminSides = ModelGetHistoryAdminSide.getAllStudents(response);
                        AdapterHistoryAdminSide adp = new AdapterHistoryAdminSide(getApplicationContext(),
                                getHistoryAdminSides);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);


    }

}