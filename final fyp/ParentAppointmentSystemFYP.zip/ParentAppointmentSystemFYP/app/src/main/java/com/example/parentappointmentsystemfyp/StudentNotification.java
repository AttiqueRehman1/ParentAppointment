package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.rv_noti_student.AdapterNotificationStudentData;
import com.example.parentappointmentsystemfyp.rv_noti_student.ModelNotificationStudentData;
import com.example.parentappointmentsystemfyp.rv_task_appointmnt_with_studntss.AdapterStudnt;
import com.example.parentappointmentsystemfyp.rv_task_appointmnt_with_studntss.ModelNotificationAppWithStudnt;

import org.json.JSONArray;

import java.util.ArrayList;

public class StudentNotification extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<ModelNotificationStudentData> notifList;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_notification);
        rv = findViewById(R.id.recylerviewForStudntNoticatin);
        getNotifiaction();
    }

    public void getNotifiaction() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                "http://192.168.93.83/BIIT_Parent_Appointment/api/student/taskGetNotificationStudent?regno="+MainActivity.regno,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        notifList = ModelNotificationStudentData.getAllNotificationAdminBell(response);
                        AdapterNotificationStudentData adp = new AdapterNotificationStudentData(getApplicationContext(),
                                notifList);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                        Toast.makeText(StudentNotification.this, "ok.", Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                AlertDialog alertDialog = new AlertDialog.Builder(StudentNotification.this).create();
                alertDialog.setTitle("Alert");
                alertDialog.setMessage("No Data Found  ");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                                finish();
                            }
                        });
                alertDialog.setCancelable(false);
                alertDialog.show();

            }
        });
        requestQueue.add(obj);
    }
}