package com.example.parentappointmentsystemfyp.rv_MySchedule_adminside;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterMySchedule extends RecyclerView.Adapter<ViewHolderMySchedule> {
    ArrayList<ModelMySchedule> list;
    Context context;
    private int lastposition = -1;


    public AdapterMySchedule(Context context,
                             ArrayList<ModelMySchedule> list) {

        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolderMySchedule onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_myschedule_adminside, parent, false);
        ViewHolderMySchedule objHolder = new ViewHolderMySchedule(vv);

        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderMySchedule holder, @SuppressLint("RecyclerView") int position) {
        animation(holder.itemView, position);

        ModelMySchedule cObj = list.get(position);

        holder.tv1.setText(cObj.getDay());
        holder.tv2.setText(cObj.getStartTime());
        holder.tv3.setText(cObj.getEndTime() + position);
        holder.switchButton.setChecked(cObj.isAvailability());


        holder.deleteIcon.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Toast.makeText(context, position + "", Toast.LENGTH_SHORT).show();
                AlertDialog ad = new AlertDialog.Builder(view.getContext()).create();
                ad.setTitle("Confirmation...");
                ad.setMessage("Delete Time slot " + "\n Day : " + cObj.getDay() + "\n" + cObj.getStartTime() + "  to  " + cObj.getEndTime());

                ad.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                        StringRequest jsonObjectRequest = new StringRequest(
                                Request.Method.GET,
                                MainActivity.url + "/Admin/DeleteTimeSlot?id=" + cObj.getTsid(),
                                new Response.Listener<String>() {

                                    @Override
                                    public void onResponse(String response) {

                                        Toast.makeText(context, "deleted successfully", Toast.LENGTH_SHORT).show();
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {

                                        Toast.makeText(context, error.networkResponse.statusCode + "", Toast.LENGTH_SHORT).show();

                                        Toast.makeText(context, "tslot f", Toast.LENGTH_SHORT).show();
                                    }
                                });


                        requestQueue.add(jsonObjectRequest);


                        // below 2 lines working fine byt not showing animation after deleteing something
//                        list.remove(position);
//                        notifyDataSetChanged();


                        animation_slideout(holder.itemView, position);

//                        try {
//                            Thread.sleep(700);
//                        } catch (InterruptedException e) {
//                            e.printStackTrace();
//                        }
                        new CountDownTimer(500, 500) {
                            public void onFinish() {
                                // When timer is finished
                                // Execute your code here
                                list.remove(position);
                                notifyDataSetChanged();
                            }

                            public void onTick(long millisUntilFinished) {
                                // millisUntilFinished    The amount of time until finished.
                            }
                        }.start();

//                        notifyItemRemoved(position);
//                        notifyItemRangeRemoved(0,getItemCount()-1);

                        ad.dismiss();
                    }
                });
                ad.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ad.dismiss();
                    }
                });
                ad.show();
               /* Snackbar.make(view, "Time Slot Deleted Successfully...", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();*/

            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

    private void animation_slideout(View view, int position) {
        if (position > -lastposition) {
            Animation slide_out = AnimationUtils.loadAnimation(context, R.anim.animation_slide_out);
            view.startAnimation(slide_out);
            lastposition = position;
        }
    }
}