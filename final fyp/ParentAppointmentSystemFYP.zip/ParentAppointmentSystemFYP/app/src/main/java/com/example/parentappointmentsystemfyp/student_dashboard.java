package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.databinding.ActivityStudentDashboardBinding;
import com.example.parentappointmentsystemfyp.recylerview_std_attndnce.StudentModel;
import com.example.parentappointmentsystemfyp.recylerview_std_attndnce.UserAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class student_dashboard extends AppCompatActivity {
    ActivityStudentDashboardBinding binding;
    ArrayList<StudentModel> slist;
    TextView bellcountStudent;

    ImageView imggNotf, imgReload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStudentDashboardBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        bellcountStudent = findViewById(R.id.bell_text_counter);
        notificationCounterForStudent();


        imggNotf = findViewById(R.id.notification_icon);
        imggNotf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(student_dashboard.this, StudentNotification.class));
            }
        });
        imgReload = findViewById(R.id.Reloading);
        imgReload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = getIntent();
                // intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                finish();
                startActivity(intent);
            }
        });

        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        String regNo = b.getString("aridNo");


        binding.btnStudentViewCgpa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                        Request.Method.GET,
                        MainActivity.url + "/Student/CGPA?regno=" + regNo,
                        null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                String cgpa = null;
                                try {
                                    cgpa = response.getString("cgpa1");

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                binding.tvShowDetails.setText("Your CGPA is " + cgpa);


                                Toast.makeText(student_dashboard.this, "Good Job",
                                        Toast.LENGTH_SHORT).show();

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(student_dashboard.this, "Failed...",
                                Toast.LENGTH_LONG).show();

                    }
                });
                requestQueue.add(jsonObjectRequest);
            }
        });

        binding.btnStudentViewAttendence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                JsonArrayRequest obj = new JsonArrayRequest(
                        Request.Method.GET,
                        MainActivity.url + "/Student/getAttendance?regno=" + regNo,
                        null,
                        new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                slist = StudentModel.getAllStudents(response);
                                String dt = "";
                                for (int i = 0; i < response.length(); i++) {
                                    try {
                                        JSONObject obj = response.getJSONObject(i);

                                        String regno = obj.getString("regNo");
                                        dt = regno;

                                        //binding.tvShowDetails.setText();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }

                                binding.tvShowDetails.setText(dt);
                                binding.tv5.setText("Attendance Sheet");

                                if (slist.isEmpty()) {

                                    AlertDialog.Builder builder = new AlertDialog.Builder(student_dashboard.this);
                                    builder.setMessage("No record Fond");
                                    builder.setTitle("Alert !");
                                    builder.setCancelable(false);
                                    /*builder.setPositiveButton("Yes", (DialogInterface.OnClickListener) (dialog, which) -> {
                                        // When the user click yes button then app will close
                                        finish();
                                    });*/

                                    builder.setNegativeButton("Okay", (DialogInterface.OnClickListener) (dialog, which) -> {
                                        // If user click no then dialog box is canceled.
                                        dialog.cancel();
                                    });
                                    AlertDialog alertDialog = builder.create();
                                    alertDialog.show();

                                } else {
                                    UserAdapter userAdapter = new UserAdapter(getApplicationContext(),
                                            slist);
                                    binding.recylerview.setAdapter(userAdapter);
                                    userAdapter.notifyDataSetChanged();
                                    Toast.makeText(student_dashboard.this, "gddddd...",
                                            Toast.LENGTH_LONG).show();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(student_dashboard.this, "Failed...",
                                Toast.LENGTH_LONG).show();

                    }
                });
                requestQueue.add(obj);
            }
        });

    }

    private void notificationCounterForStudent() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                "http://192.168.93.83/BIIT_Parent_Appointment/api/student/TaskCountNotificationStd?id="+MainActivity.regno,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        bellcountStudent.setText(response + "");
                        Toast.makeText(getApplicationContext(), "Good", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(student_dashboard.this, error.toString() + "", Toast.LENGTH_SHORT).show();
                    }
                });

        requestQueue.add(jsonObjectRequest);
    }

}