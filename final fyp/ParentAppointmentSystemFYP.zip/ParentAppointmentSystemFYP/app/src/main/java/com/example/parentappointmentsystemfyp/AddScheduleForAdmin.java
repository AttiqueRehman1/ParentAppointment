package com.example.parentappointmentsystemfyp;

import static java.lang.Double.valueOf;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class AddScheduleForAdmin extends AppCompatActivity {
    CalendarView calendarView1, calendarView2;
    Spinner spnStartTime, spnEndTime;
    static String startDate = "";
    static String endDate = "";
    TextView tv1, tv2;
    Button btnConfirmTimeSchedule;
    Button btnCACl1, btnCACl2, okcal1, okcal2, okcal3, okcal4;
    ArrayList<String> spn1 = new ArrayList<String>();
    ArrayList<String> spn2 = new ArrayList<String>();
    String getStartTime,getEndTime;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule_for_admin);
        spn1.add("9");
        spn1.add("10");
        spn1.add("11");
        spn1.add("12");
        spn2.add("1");
        spn2.add("2");
        spn2.add("3");
        spn2.add("4");
        spn2.add("5");

        spnStartTime = findViewById(R.id.spnStartTime);
        spnEndTime = findViewById(R.id.spnEndTime);
        btnConfirmTimeSchedule = findViewById(R.id.btnConfirmTimeSchedule);

        ArrayAdapter adp1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, spn1);
        adp1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnStartTime.setAdapter(adp1);


        ArrayAdapter adp2 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, spn2);
        adp2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnEndTime.setAdapter(adp2);


        tv1 = findViewById(R.id.tv11);
        tv2 = findViewById(R.id.tv22);


        AlertDialog ad = new AlertDialog.Builder(AddScheduleForAdmin.this).create();
        View v = LayoutInflater.from(AddScheduleForAdmin.this).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
        ad.setView(v);
        ad.create();

        AlertDialog ad2 = new AlertDialog.Builder(AddScheduleForAdmin.this).create();
        View v2 = LayoutInflater.from(AddScheduleForAdmin.this).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
        ad2.setView(v2);
        ad2.create();


        btnCACl1 = findViewById(R.id.getCalnder1DAte);
        btnCACl2 = findViewById(R.id.getCalnder2DAte);
        btnCACl2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad2.show();

            }
        });
        btnCACl1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad.show();
            }
        });
        calendarView1 = ad.findViewById(R.id.calander);
        calendarView2 = ad2.findViewById(R.id.calander);
        calendarView1.setMinDate(System.currentTimeMillis() - 1000);
        calendarView2.setMinDate(System.currentTimeMillis() - 1000);

        calendarView1.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Double mont = valueOf(month) + 1;
                int month1 = mont.intValue();
                startDate = dayOfMonth + "/" + month1 + "/" + year;
                Toast.makeText(AddScheduleForAdmin.this, startDate, Toast.LENGTH_SHORT).show();

            }
        });
        calendarView2.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Double mont = valueOf(month) + 1;
                int month1 = mont.intValue();
                endDate = dayOfMonth + "/" + month1 + "/" + year;
                Toast.makeText(AddScheduleForAdmin.this, endDate, Toast.LENGTH_SHORT).show();

            }
        });


        okcal1 = ad.findViewById(R.id.btnOk);
        okcal2 = ad.findViewById(R.id.btnCancel);
        okcal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv1.setText(startDate);

                ad.dismiss();
            }
        });

        okcal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad.dismiss();
            }
        });


        okcal3 = ad2.findViewById(R.id.btnOk);
        okcal4 = ad2.findViewById(R.id.btnCancel);

        okcal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                tv2.setText(endDate);
                ad2.dismiss();


            }
        });
        okcal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad2.dismiss();
            }
        });
        btnConfirmTimeSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               getStartTime = spnStartTime.getSelectedItem().toString();
                getEndTime = spnEndTime.getSelectedItem().toString();
                timeScheduleManallyAdd();
                finish();

            }
        });
    }

    private void timeScheduleManallyAdd() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest jsonObjectRequest = new StringRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/AddTimeSlotbyStartEnd?sdt=" + startDate + "&edt=" + endDate + "&id=" + MainActivity.cnic + "+&st="+getStartTime+"&et="+getEndTime,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {


                        Toast.makeText(getApplicationContext(), "Slot Added Successfully", Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getApplicationContext(), "Slot Added F", Toast.LENGTH_SHORT).show();
                    }
                });
        requestQueue.add(jsonObjectRequest);
    }
}