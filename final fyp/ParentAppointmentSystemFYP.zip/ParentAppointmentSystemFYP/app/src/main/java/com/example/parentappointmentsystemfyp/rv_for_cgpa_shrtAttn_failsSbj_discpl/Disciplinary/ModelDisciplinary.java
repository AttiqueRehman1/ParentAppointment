package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.Disciplinary;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelDisciplinary {
    private  String regno,disciplinary;

    public  static ArrayList<ModelDisciplinary> getAllStudentDisciplinaryList(JSONArray array)
    {
        ArrayList<ModelDisciplinary> slist=new ArrayList<>();
        for(int i=0;i<array.length();i++){

            try {
                JSONObject obj=array.getJSONObject(i);
                ModelDisciplinary smodel=new ModelDisciplinary();
                smodel.regno=obj.getString("regNo");
                smodel.disciplinary=obj.getString("actions");




                slist.add(smodel);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return  slist;
    }

    public String getRegno() {
        return regno;
    }

    public void setRegno(String regno) {
        this.regno = regno;
    }

    public String getDisciplinary() {
        return disciplinary;
    }

    public void setDisciplinary(String disciplinary) {
        this.disciplinary = disciplinary;
    }
}
