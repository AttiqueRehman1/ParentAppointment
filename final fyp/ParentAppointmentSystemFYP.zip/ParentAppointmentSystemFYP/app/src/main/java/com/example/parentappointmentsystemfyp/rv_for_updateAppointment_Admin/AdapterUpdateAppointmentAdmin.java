package com.example.parentappointmentsystemfyp.rv_for_updateAppointment_Admin;

import static java.lang.Double.valueOf;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterUpdateAppointmentAdmin extends RecyclerView.Adapter<ViewHolderUpdateAppointmentAdmin> {
    ArrayList<ModelUpdateAppointmentAdmin> list;
    private int lastposition = -1;
    Button btnAlertSubmit;
    Button btnOk, btnCancel;
    CalendarView calendarView;
    String date;
    EditText remarks;
    static boolean flagheld, flagwait, flagreschedule = false;
    Context context;

    public AdapterUpdateAppointmentAdmin(Context context,
                                         ArrayList<ModelUpdateAppointmentAdmin> list) {
        this.list = list;
        this.context = context;

    }

    @NonNull
    @Override
    public ViewHolderUpdateAppointmentAdmin onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vv = LayoutInflater.from(parent.getContext()).inflate(R.layout.cell_update_appointments_admin, parent, false);
        ViewHolderUpdateAppointmentAdmin objHolder = new ViewHolderUpdateAppointmentAdmin(vv);
        return objHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderUpdateAppointmentAdmin holder, @SuppressLint("RecyclerView") int position) {
        animation(holder.itemView, position);
        ModelUpdateAppointmentAdmin cObj = list.get(position);
        //boolean flagheld,flagwait,flagreschedule=false;
        holder.tv1.setText("Reg No : " + cObj.getRegNo() + "   " + cObj.getMid());
        holder.tv2.setText("Reason : " + cObj.getReason());
        holder.tv3.setText("Date : " + cObj.getDate());
        holder.tv4.setText("Start Time : " + cObj.getStartTime() + position + "  " + cObj.getTsid());
        holder.tv5.setText("End Time : " + cObj.getEndTime() + "      Status:     " + cObj.getStatus());

        if (cObj.getStatus().equals("Held")) {
            holder.held1.setVisibility(View.GONE);
            holder.wait1.setVisibility(View.GONE);
            holder.reschedule1.setVisibility(View.GONE);
        }
        holder.held1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                androidx.appcompat.app.AlertDialog ad = new androidx.appcompat.app.AlertDialog.Builder(view.getContext()).create();
                View v = LayoutInflater.from(view.getContext()).inflate(R.layout.alert_held_, null);
                ad.setView(v);
                ad.create();
                ad.show();
                remarks = v.findViewById(R.id.etxtSubmitttion);

                btnAlertSubmit = v.findViewById(R.id.btnAlertSubmitOnHeld);
                btnAlertSubmit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if (remarks.getText().toString().isEmpty()) {
                            remarks.setFocusable(true);
                            remarks.setError("Please Enter Feedback ");
                            return;

                        }
                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                        StringRequest jsonObjectRequest = new StringRequest(
                                Request.Method.GET,
                                MainActivity.url + "/Admin/UpdateMeetingStatus?mid=" + cObj.getMid() + "&status=Held&remarks=" + remarks.getText().toString(),
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        Toast.makeText(context, "Feedback Submitted", Toast.LENGTH_SHORT).show();
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(context, "remarks f", Toast.LENGTH_SHORT).show();
                                    }
                                });
                        requestQueue.add(jsonObjectRequest);
                        list.remove(position);
                        notifyDataSetChanged();
                        ad.dismiss();
                    }
                });
            }
        });
        holder.wait1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog alertDialog = new AlertDialog.Builder(view.getContext()).create();
                alertDialog.setTitle("WAITING LIST");
                alertDialog.setMessage("This Appointment will be go into Waiting List");
                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Add in WaitingList",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                RequestQueue requestQueue = Volley.newRequestQueue(context);
                                StringRequest jsonObjectRequest = new StringRequest(
                                        Request.Method.GET,
                                        MainActivity.url + "/Admin/UpdateMeetingStatus?mid=" + cObj.getMid() + "&status=Waiting&remarks=a",
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {
                                                Toast.makeText(context, "Slot added into Waiting list", Toast.LENGTH_SHORT).show();
                                            }
                                        },
                                        new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Toast.makeText(context, error.toString() + "", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                requestQueue.add(jsonObjectRequest);
                                list.remove(position);
                                notifyDataSetChanged();
                                dialog.dismiss();
                            }
                        });
                alertDialog.setIcon(R.drawable.ic_baseline_refresh_24);
                alertDialog.show();
            }
        });
        holder.reschedule1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog ad = new AlertDialog.Builder(view.getContext()).create();
                View vv = LayoutInflater.from(context).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
                ad.setView(vv);
                ad.show();
                calendarView = ad.findViewById(R.id.calander);
                calendarView.setMinDate(System.currentTimeMillis() - 1000);
                calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

                    @Override
                    public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                        Double mont = valueOf(month) + 1;
                        int month1 = mont.intValue();
                        date = dayOfMonth + "/" + month1 + "/" + year;
                        Toast.makeText(context, date, Toast.LENGTH_SHORT).show();

                    }
                });

                btnCancel = ad.findViewById(R.id.btnCancel);
                btnCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ad.dismiss();
                    }
                });


                btnOk = ad.findViewById(R.id.btnOk);
                btnOk.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                        StringRequest jsonObjectRequest = new StringRequest(
                                Request.Method.GET,
                                MainActivity.url + "/Admin/ReSheduleMeeting?tsid=" + cObj.getTsid() + "&date=" + date,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        Toast.makeText(context, "reschedule ok", Toast.LENGTH_SHORT).show();
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
                                    }
                                });
                        requestQueue.add(jsonObjectRequest);
                        list.remove(position);
                        notifyDataSetChanged();
                        ad.dismiss();


                    }
                });


            }
        });


    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private void animation(View view, int position) {

        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }
}
