package com.example.parentappointmentsystemfyp.rv_for_HistoryButton_prntSide;

import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;
import com.example.parentappointmentsystemfyp.parent_dashboard;

public class ViewHolderHistoryButton extends RecyclerView.ViewHolder {
    TextView tv1, tv2, tv3, tv4, tv5, tv6, att1, att2, att3;
    Button btnR;
    RatingBar ratingBar1, ratingBar2, ratingBar3;
    CheckBox checkBox1, checkBox2, checkBox3, checkBox4, checkBox5, checkBox6;

    public ViewHolderHistoryButton(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.tvHB01);
        tv2 = v.findViewById(R.id.tvHB02);
        tv3 = v.findViewById(R.id.tvHB03);
        tv4 = v.findViewById(R.id.tvHB04);
        tv5 = v.findViewById(R.id.tvHB05);
        tv6 = v.findViewById(R.id.tvHB06);
        btnR = v.findViewById(R.id.btnHB01);
        ratingBar1 = v.findViewById(R.id.rbHB01);
        ratingBar2 = v.findViewById(R.id.rbHB02);
        ratingBar3 = v.findViewById(R.id.rbHB03);
        att1 = v.findViewById(R.id.tvatt01);
        att2 = v.findViewById(R.id.tvatt02);
        att3 = v.findViewById(R.id.tvatt03);


    }

}
