package com.example.parentappointmentsystemfyp.rv_for_timeSlot_RefreSideDataModified;


import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.MainActivity;
import com.example.parentappointmentsystemfyp.R;
import com.example.parentappointmentsystemfyp.ReferSideDataModified;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class AdapterTimeSlotReferDataModified extends RecyclerView.Adapter<ViewHolderTimeSlotReferDataModified> {
    ArrayList<ModelTimeSlotReferDataModified> list;
    Context context;
    private int lastposition = -1;
    public static int timeSLot_id, position, id_get_from_btn, admin_id_get_from_btn;
    public static String time_get_from_btn;
    static boolean btnStatus = false;


    public AdapterTimeSlotReferDataModified(Context context,
                                            ArrayList<ModelTimeSlotReferDataModified> list) {
        this.list = list;
        this.context = context;
        setHasStableIds(true);

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @NonNull
    @Override
    public ViewHolderTimeSlotReferDataModified onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.timeslot_cell_design, parent, false);
        ViewHolderTimeSlotReferDataModified objHolder = new ViewHolderTimeSlotReferDataModified(v);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderTimeSlotReferDataModified holder, int position) {
        animation(holder.itemView, position);
        final ModelTimeSlotReferDataModified cObj = list.get(position);
        timeSLot_id = cObj.getTimeSlot_id();
        admin_id_get_from_btn = cObj.getAdmin_id_from_timeslot();
        AdapterTimeSlotReferDataModified.position = holder.getAdapterPosition();
        holder.tv1.setText(cObj.getDay());
        holder.btn.setText(cObj.getStartTime() + "  " + cObj.getEndTime());
        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest jsonObjectRequest = new StringRequest(
                        Request.Method.GET,
                        MainActivity.url + "/Admin/ReferTo?mid=" + ReferSideDataModified.midIntent + "&refer=" + ReferSideDataModified.roleIntent + "&tsid=" + cObj.getTimeSlot_id(),
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                Toast.makeText(context, "g", Toast.LENGTH_SHORT).show();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(context, error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
                requestQueue.add(jsonObjectRequest);
            }
        });


    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}