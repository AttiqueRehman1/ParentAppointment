package com.example.parentappointmentsystemfyp.rv_for_cgpa_shrtAttn_failsSbj_discpl.SHORT_ATTENDANCE;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderShortAttendance extends RecyclerView.ViewHolder {
    TextView tv1,tv2,tv3;
    public ViewHolderShortAttendance(@NonNull View v) {
        super(v);
        tv1= v.findViewById(R.id.dtv1);
        tv2 = v.findViewById(R.id.dtv2);
        tv3=v.findViewById(R.id.stv3);


    }
}




