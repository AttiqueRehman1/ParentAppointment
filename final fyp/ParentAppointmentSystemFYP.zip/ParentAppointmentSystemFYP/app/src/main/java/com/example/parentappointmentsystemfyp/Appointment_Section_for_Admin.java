package com.example.parentappointmentsystemfyp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ContentInfoCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.parentappointmentsystemfyp.databinding.ActivityAppointmentSectionForAdminBinding;
import com.example.parentappointmentsystemfyp.databinding.ActivityMainBinding;

public class Appointment_Section_for_Admin extends AppCompatActivity {
    ActivityAppointmentSectionForAdminBinding binding;
    static boolean flagcgpa, flagshortAttndnce, flagdisciplinary, flagFailedSubject = false;
    Button btn;
    public static boolean flagPrnt, flagStudnt = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAppointmentSectionForAdminBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        binding.btnCAllParentTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Appointment_Section_for_Admin.flagPrnt = true;
                Appointment_Section_for_Admin.flagStudnt = false;

                startActivity(new Intent(Appointment_Section_for_Admin.this, TaskFYP.class));

            }
        });

        binding.btnCAllStudentTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Appointment_Section_for_Admin.flagPrnt = false;
                Appointment_Section_for_Admin.flagStudnt = true;
                startActivity(new Intent(Appointment_Section_for_Admin.this, TaskFYP.class));

            }
        });


        binding.btnUpdateAppointmentsFroADmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagcgpa = true;
                flagshortAttndnce = false;
                flagdisciplinary = false;
                flagFailedSubject = false;
                Intent i = new Intent(getApplicationContext(), Data_studnt_cgpa_shrt_failedsubject.class);
                startActivity(i);

            }
        });
        binding.btnDisciplinary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagcgpa = false;
                flagshortAttndnce = false;
                flagdisciplinary = true;
                flagFailedSubject = false;
                Intent i = new Intent(getApplicationContext(), Data_studnt_cgpa_shrt_failedsubject.class);
                startActivity(i);

            }
        });
        binding.btnFailedSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagcgpa = false;
                flagshortAttndnce = false;
                flagdisciplinary = false;
                flagFailedSubject = true;
                Intent i = new Intent(getApplicationContext(), Data_studnt_cgpa_shrt_failedsubject.class);
                startActivity(i);

            }
        });
        binding.btnShortAttendanceAdminside.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flagcgpa = false;
                flagshortAttndnce = true;
                flagdisciplinary = false;
                flagFailedSubject = false;
                Intent i = new Intent(getApplicationContext(), Data_studnt_cgpa_shrt_failedsubject.class);
                startActivity(i);
            }
        });
        binding.btnIndivisualAppointmnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Appointment_Section_for_Admin.this, IndividualAppointmentForAdmin.class);
                startActivity(i);
            }
        });

    }
}