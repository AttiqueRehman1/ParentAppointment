package com.example.parentappointmentsystemfyp.rv_waitinglist_adminside;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelWaitingListAdminSide {

    String regNo, date, reason, parentId, adminId, status;
    int tsId, id;


    public static ArrayList<ModelWaitingListAdminSide> getAllWaitingList(JSONArray array) {
        ArrayList<ModelWaitingListAdminSide> waitinglist = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {

            try {
                JSONObject obj = array.getJSONObject(i);
                ModelWaitingListAdminSide model = new ModelWaitingListAdminSide();
                model.regNo = obj.getString("regNo");
                model.date = obj.getString("date");
                model.reason = obj.getString("reason");
                model.parentId = obj.getString("parentId");
                model.adminId = obj.getString("adminId");
                model.status = obj.getString("status");
                model.tsId = obj.getInt("tsId");
                model.id = obj.getInt("id");
                waitinglist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return waitinglist;
    }

    public int getId() {
        return id;
    }

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getTsId() {
        return tsId;
    }

    public void setTsId(int tsId) {
        this.tsId = tsId;
    }
}
