package com.example.parentappointmentsystemfyp;

import static java.lang.Double.valueOf;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.parentappointmentsystemfyp.rv_task_apoointment_with_parents.AdapterParent;
import com.example.parentappointmentsystemfyp.rv_task_apoointment_with_parents.ModelNotificationAppWithParent;
import com.example.parentappointmentsystemfyp.rv_task_appointmnt_with_studntss.AdapterStudnt;
import com.example.parentappointmentsystemfyp.rv_task_appointmnt_with_studntss.ModelNotificationAppWithStudnt;

import org.json.JSONArray;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


public class TaskFYP extends AppCompatActivity {
    RecyclerView rv;
    ArrayList<ModelNotificationAppWithParent> stasklist;
    ArrayList<ModelNotificationAppWithStudnt> prnttasklist;
    Button btnSetApp;
    Button btnSendApp, btnOk, btnCancel;
    CalendarView calendarView;
    String date;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_fyp);
        rv = findViewById(R.id.recylerviewForTaskStudent);
        AlertDialog ad = new AlertDialog.Builder(TaskFYP.this).create();
        View v = LayoutInflater.from(TaskFYP.this).inflate(R.layout.alertdialog_calander_gettingdata_for_adminappointmnt, null);
        ad.setView(v);
        ad.create();

        calendarView = ad.findViewById(R.id.calander);
        calendarView.setMinDate(System.currentTimeMillis() - 1000);
        date = new SimpleDateFormat("d/M/yyyy", Locale.getDefault()).format(new Date());
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                Double mont = valueOf(month) + 1;
                int month1 = mont.intValue();
                date = dayOfMonth + "/" + month1 + "/" + year;

                Toast.makeText(TaskFYP.this, date, Toast.LENGTH_SHORT).show();

            }
        });

        btnCancel = ad.findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad.dismiss();
                finish();
            }
        });


        btnOk = ad.findViewById(R.id.btnOk);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Appointment_Section_for_Admin.flagStudnt) {
                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET,
                            MainActivity.url + "/Admin/TaskLowCGPAAppointmentStudentCall?date=" + date, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Toast.makeText(getApplicationContext(), "Appointment Set Successfully", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast.makeText(TaskFYP.this, error.toString() + "", Toast.LENGTH_SHORT).show();
                        }
                    });
                    requestQueue.add(jsonObjectRequest);
                }

                if (Appointment_Section_for_Admin.flagPrnt) {
                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    StringRequest jsonObjectRequest = new StringRequest(Request.Method.GET,
                            MainActivity.url + "/Admin/TaskLowCGPAAppointmentPrentCall?date=" + date, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Toast.makeText(getApplicationContext(), "Appointment Set Successfully", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast.makeText(TaskFYP.this, error.toString() + "", Toast.LENGTH_SHORT).show();
                        }
                    });
                    requestQueue.add(jsonObjectRequest);

                }
            }
        });


        btnSetApp = findViewById(R.id.setAppTask);
        btnSetApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ad.show();
            }
        });
        if (Appointment_Section_for_Admin.flagStudnt)
            studentsTask();
        if (Appointment_Section_for_Admin.flagPrnt)
            prntTask();

    }


    public void prntTask() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/TaskGetLowCGPASParentTask",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        stasklist = ModelNotificationAppWithParent.getAllNotificationAdminBell(response);
                        AdapterParent adp = new AdapterParent(getApplicationContext(),
                                stasklist);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                        Toast.makeText(TaskFYP.this, "ok.", Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }

    public void studentsTask() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest obj = new JsonArrayRequest(
                Request.Method.GET,
                MainActivity.url + "/Admin/TaskGetLowCGPAStudentsTask",
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        prnttasklist = ModelNotificationAppWithStudnt.getAllNotificationAdminBell(response);
                        AdapterStudnt adp = new AdapterStudnt(getApplicationContext(),
                                prnttasklist);
                        rv.setAdapter(adp);
                        adp.notifyDataSetChanged();
                        Toast.makeText(TaskFYP.this, "ok.", Toast.LENGTH_SHORT).show();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Failed...",
                        Toast.LENGTH_LONG).show();

            }
        });
        requestQueue.add(obj);
    }
}