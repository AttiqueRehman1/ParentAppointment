package com.example.parentappointmentsystemfyp.recylerView_for_timeslot_parentSide;


import static android.content.ContentValues.TAG;


import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

import java.util.ArrayList;

public class AdapterTimeSlot extends RecyclerView.Adapter<ViewHolderTimeSlot> {
    ArrayList<ModelTimeSlot> list;
    Context context;
    private int lastposition = -1;
    public static int tsid;
    public static String adminId;
    public static String time;


    public AdapterTimeSlot(Context context,
                           ArrayList<ModelTimeSlot> list) {
        this.list = list;
        this.context = context;

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @NonNull
    @Override
    public ViewHolderTimeSlot onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.timeslot_cell_design, parent, false);
        ViewHolderTimeSlot objHolder = new ViewHolderTimeSlot(v);
        return objHolder;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolderTimeSlot holder, @SuppressLint("RecyclerView") int position) {
        animation(holder.itemView, position);
        ModelTimeSlot obj = list.get(position);
        holder.tv1.setText(obj.getDay());
        holder.btn.setText(obj.getStartTime() + "\n" + obj.getEndTime());

        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = holder.getAdapterPosition();
                tsid = obj.getTsid();
                adminId = obj.getAdminId();
                time = obj.getStartTime();
                if (holder.itemView.isSelected()) {
                    holder.btn.setBackgroundResource(R.drawable.btn_color_change_by_clicking);
                    holder.itemView.setSelected(false);
                } else {
                    holder.btn.setBackgroundResource(R.drawable.reverse_color_for_recylerview);
                    holder.itemView.setSelected(true);
                }


            }
        });


    }

    @Override
    public void setHasStableIds(boolean hasStableIds) {
        super.setHasStableIds(hasStableIds);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    private void animation(View view, int position) {
        if (position > -lastposition) {
            Animation slide_in = AnimationUtils.loadAnimation(context, R.anim.animation_slide_in);
            view.startAnimation(slide_in);
            lastposition = position;
        }

    }

}