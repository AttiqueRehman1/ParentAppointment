package com.example.parentappointmentsystemfyp.rv_for_timeSlot_RefreSideDataModified;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parentappointmentsystemfyp.R;

public class ViewHolderTimeSlotReferDataModified extends RecyclerView.ViewHolder {
    TextView tv1;
    Button btn;

    public ViewHolderTimeSlotReferDataModified(@NonNull View v) {
        super(v);
        tv1 = v.findViewById(R.id.dtv1);
        btn = v.findViewById(R.id.btn1);
//       btn.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                if (event.getAction() == (MotionEvent.ACTION_DOWN)) {
//                    btn.setBackgroundResource(android.R.color.holo_red_dark);
//                }
//                if (event.getAction() == (MotionEvent.ACTION_UP)) {
//                    //v.getBackground().setColorFilter(Color.parseColor("#00ff00"), PorterDuff.Mode.DARKEN);
//                    btn.setBackgroundResource(android.R.color.holo_green_dark);
//                }
//
//                return true;
//
//            }
//
//        });

        // Toast.makeText(btn.getContext(), "TimeSlot_ID "+AdapterTimeSlot.timeSLot_id, Toast.LENGTH_SHORT).show();


    }
}




