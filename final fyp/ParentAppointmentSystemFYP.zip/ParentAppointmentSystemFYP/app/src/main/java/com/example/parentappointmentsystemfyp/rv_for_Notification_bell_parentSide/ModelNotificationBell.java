package com.example.parentappointmentsystemfyp.rv_for_Notification_bell_parentSide;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ModelNotificationBell {

    String regNo,reason,projectIssue,status,startTime,endTime,adminId,date;
    int mid,tsid;

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public int getTsid() {
        return tsid;
    }

    public void setTsid(int tsid) {
        this.tsid = tsid;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public  static ArrayList<ModelNotificationBell> getAllStudents(JSONArray array)
    {
        ArrayList<ModelNotificationBell> notificationlist=new ArrayList<>();
        for(int i=0;i<array.length();i++){

            try {
                JSONObject obj=array.getJSONObject(i);
                ModelNotificationBell model=new ModelNotificationBell();
                model.regNo=obj.getString("regNo");
                model.reason=obj.getString("reason");
                model.status=obj.getString("status");
                model.startTime=obj.getString("startTime");
                model.endTime=obj.getString("endTime");
                model.date=obj.getString("date");
                model.mid=obj.getInt("mid");
                model.adminId=obj.getString("adminId");
                model.tsid=obj.getInt("tsid");
                notificationlist.add(model);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
        return  notificationlist;















}

    public String getRegNo() {
        return regNo;
    }

    public void setRegNo(String regNo) {
        this.regNo = regNo;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getProjectIssue() {
        return projectIssue;
    }

    public void setProjectIssue(String projectIssue) {
        this.projectIssue = projectIssue;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }}
